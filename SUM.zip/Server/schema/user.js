// 导入定义规则的包
const joi = require('joi');

// 定义用户名和密码的验证规则
/**
 * string() - 值必须是字符串类型
 * alphanum() - 值只能包含 a-zA-Z0-9（字母和数字）
 * min(length) - 最小长度
 * max(length) - 最大长度
 * required() - 值是必填项，不能为 undefined
 * pattern(正则表达式) - 值必须符合指定的正则表达式规则
 */
const username = joi.string().alphanum().min(3).max(10).required(); // 用户名必须是 3-10 位的字母或数字
const password = joi.string().pattern(/^[\S]{6,12}$/).required(); // 密码必须是 6-12 位的非空字符（不能包含空格）
const email = joi.string().email().optional(); // 邮箱必须符合 email 格式，可以为空

// 定义验证规则对象 - 注册和登录表单数据
exports.register = {
    body: {
        username, // 用户名
        password, // 密码
        email     // 邮箱（可选）
    }
}

// 定义验证规则对象 - 更新密码
exports.updatePwd = {
    body: {
        oldPwd: password, // 旧密码，符合密码规则
        newPwd: joi.not(joi.ref('oldPwd')).concat(password) // 新密码，不能与旧密码相同，且符合密码规则
    }
}

// 定义验证规则对象 - 更新用户头像
exports.updateAvatar = {
    body: {
        avatar: joi.alternatives().try(
            joi.binary(),       // 允许 Buffer 类型（即二进制数据）
            joi.string().uri()  // 允许 URL 格式
        ).required(), // 头像为必填项
    }
}
