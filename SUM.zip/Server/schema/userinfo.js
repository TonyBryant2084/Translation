const joi = require('joi');

// 定义验证规则
const id = joi.number().integer().min(1); // ID 必须是大于等于 1 的整数
const nickname = joi.string().optional(); // 昵称是可选项，必须是字符串
const email = joi.string().email().optional(); // 邮箱必须符合 email 格式，并且是可选项
const gender = joi.valid('男', '女', '保密').optional(); // 性别必须是 '男'、'女' 或 '保密'，并且是可选项

// 导出更新用户信息的验证规则
exports.updateUserInfo = {
    body: {
        id,
        nickname,
        email,
        gender
    }
};
