// 用户信息管理模块

// 导入数据库操作模块
const db = require('../db/index')
const bcrypt = require('bcryptjs')

// 获取用户基本信息
exports.getUserInfo = (req, res) => {
    // 定义 SQL 语句，查询用户的基本信息
    const sqlStr = 'SELECT id, username, nickname, email, user_pic, gender FROM ev_users WHERE username=?';

    // 注意：req.user 属性由 express-jwt 中间件解析 Token 后自动挂载，新版使用 req.auth
    db.query(sqlStr, req.user.username, (err, result) => {
        // 1. SQL 语句执行失败
        if (err) {
            return res.cc(err.message);
        }
        // 2. 查询成功，但用户不存在
        if (result.length !== 1) {
            return res.cc('获取用户信息失败！');
        }
        // 3. 返回用户信息
        res.send({
            status: 0,
            msg: '获取用户信息成功!',
            data: result[0]
        });
    });
};

// 修改用户基本信息
exports.changeUserInfo = (req, res) => {
    // 从请求体中解构出需要更新的字段
    const { nickname, email, gender } = req.body;

    // 存储动态构建的 SQL 更新语句
    let setClause = [];
    let values = [];

    // 根据请求体中的字段动态构建 SET 子句
    if (nickname) {
        setClause.push('nickname = ?');
        values.push(nickname);
    }
    if (email) {
        setClause.push('email = ?');
        values.push(email);
    }
    if (gender) {
        setClause.push('gender = ?');
        values.push(gender);
    }

    // 如果没有提供需要更新的字段，则返回错误信息
    if (setClause.length === 0) {
        return res.cc('没有提供更新的字段', 1);
    }

    // 构造完整的 SQL 语句
    const sqlStr = `UPDATE ev_users SET ${setClause.join(', ')} WHERE id = ?`;

    // 将用户 ID 添加到 SQL 语句参数列表中
    values.push(req.user.id);

    // 执行 SQL 语句
    db.query(sqlStr, values, (err, result) => {
        if (err) {
            return res.cc(err);
        }
        if (result.affectedRows !== 1) {
            return res.cc('修改用户基本信息失败');
        }
        return res.cc('修改用户基本信息成功', 0);
    });
};

// 更新用户密码
exports.updatePassword = (req, res) => {
    // 定义 SQL 语句，根据用户 ID 查询用户信息
    const sqlStr = 'SELECT * FROM ev_users WHERE id=?';

    // 执行查询
    db.query(sqlStr, req.user.id, (err, result) => {
        // 1. 查询失败
        if (err) return res.cc(err);
        // 2. 查询成功，但用户不存在
        if (result.length !== 1) return res.cc('用户不存在');
        // 3. 校验旧密码是否正确
        const compareResult = bcrypt.compareSync(req.body.oldPwd, result[0].password);
        if (!compareResult) return res.cc('旧密码错误');

        // 4. 更新密码
        const sqlStr1 = 'UPDATE ev_users SET password=? WHERE id=?';
        // 对新密码进行加密处理
        const newPwd = bcrypt.hashSync(req.body.newPwd, 10);
        db.query(sqlStr1, [newPwd, req.user.id], (err, result) => {
            // 1. 更新失败
            if (err) return res.cc(err);
            // 2. 更新成功但影响行数不为 1
            if (result.affectedRows !== 1) return res.cc('更新密码失败');
            res.cc('更新密码成功', 0);
        });
    });
};

// 更新用户头像
exports.updateAvatar = (req, res) => {
    // 定义 SQL 语句，更新用户头像
    const sqlStr = 'UPDATE ev_users SET user_pic=? WHERE id=?';

    // 执行 SQL 语句
    db.query(sqlStr, [req.body.avatar, req.user.id], (err, result) => {
        // 1. 更新失败
        if (err) return res.cc(err);
        // 2. 更新成功但影响行数不为 1
        if (result.affectedRows !== 1) return res.cc('更新头像失败');
        res.cc('更新头像成功', 0);
    });
};

// 删除用户
exports.deleteUser = (req, res) => {
    // 定义 SQL 语句，根据用户名删除用户
    const sqlStr = 'DELETE FROM ev_users WHERE username=?';

    // 执行 SQL 语句
    db.query(sqlStr, req.body.username, (err, result) => {
        // 1. 删除失败
        if (err) return res.cc(err);
        if (result.affectedRows === 0) return res.cc('用户不存在');
        // 2. 删除成功但影响行数不为 1
        if (result.affectedRows !== 1) return res.cc('删除用户失败');
        res.cc('删除用户成功', 0);
    });
};

// 展示所有用户信息
exports.showAllUser = (req, res) => {
    // 定义 SQL 语句，查询所有用户
    const sqlStr = 'SELECT * FROM ev_users';

    // 执行 SQL 语句
    db.query(sqlStr, (err, result) => {
        // 1. 查询失败
        if (err) return res.cc(err);
        // 2. 查询成功但数据为空
        if (result.length === 0) return res.cc('获取用户信息失败');
        // 3. 返回查询结果
        res.send({
            status: 0,
            msg: '获取用户信息成功',
            data: result
        });
    });
};
