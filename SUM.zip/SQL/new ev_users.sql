-- 1. 删除旧表（如果存在）
DROP TABLE IF EXISTS `ev_users`;

-- 2. 创建新的 ev_users 表
CREATE TABLE `ev_users` (
  `id` int NOT NULL AUTO_INCREMENT,            -- 用户ID，自增主键
  `username` varchar(100) NOT NULL,            -- 用户名，唯一，不可为空
  `password` varchar(100) NOT NULL,            -- 密码，不可为空
  `nickname` varchar(100) DEFAULT NULL,        -- 昵称，可为空
  `email` varchar(100) DEFAULT NULL,           -- 邮箱，可为空
  `user_pic` varchar(255) DEFAULT NULL,        -- 用户头像，改为 NULL，使用触发器处理
  `gender` varchar(2) DEFAULT NULL,            -- 性别，可为空
  `role` tinyint(1) DEFAULT '0',               -- 用户角色，默认 0
  PRIMARY KEY (`id`),                          -- 设置主键
  UNIQUE KEY `ev_users_unique` (`username`)    -- 确保用户名唯一
) ENGINE=InnoDB AUTO_INCREMENT=40 
  DEFAULT CHARSET=utf8mb4 
  COLLATE=utf8mb4_0900_ai_ci 
  COMMENT='用户信息表';

-- 3. 创建触发器，在插入数据时随机设置 user_pic
DELIMITER $$

CREATE TRIGGER `before_insert_ev_users`
BEFORE INSERT ON `ev_users`
FOR EACH ROW
BEGIN
    IF NEW.user_pic IS NULL THEN
        SET NEW.user_pic = CASE FLOOR(1 + RAND() * 3)
            WHEN 1 THEN 'https://img.520wangming.com/uploads/allimg/2021032508/vmmdkpkov1f.jpg'
            WHEN 2 THEN 'https://img.520wangming.com/uploads/allimg/2021032508/owygh5svzfi.jpg'
            ELSE 'https://img.520wangming.com/uploads/allimg/2021032508/5c0pknwlgcj.jpg'
        END;
    END IF;
END $$

DELIMITER ;