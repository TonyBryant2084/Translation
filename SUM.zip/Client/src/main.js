import Vue from 'vue'; // 导入 Vue 构造函数
import App from './App.vue'; // 导入根组件 App.vue
import router from './router'; // 导入路由配置
import ElementUI from 'element-ui'; // 导入 Element UI 库，用于 UI 组件
import 'element-ui/lib/theme-chalk/index.css'; // 导入 Element UI 的样式
import axios from './api/axios'; // 导入自定义的 axios 实例
Vue.prototype.$axios = axios; // 将 axios 挂载到 Vue 原型上，使其在所有组件中可访问

import BaiduMap from 'vue-baidu-map'; // 导入百度地图插件
Vue.config.productionTip = false; // 关闭生产环境提示，防止控制台输出默认提示信息

// 使用 Element UI 插件
Vue.use(ElementUI);

// 使用百度地图插件，并传入百度地图的 API 密钥
Vue.use(BaiduMap, {
  ak: 'dNFqfjD7d9G3c35wi7dJoBrO7hVPUr0L', // 替换为你自己的百度地图 API 密钥
});

// 创建 Vue 实例，挂载到 #app 元素上
new Vue({
  router, // 注册路由
  render: h => h(App) // 渲染根组件 App
}).$mount('#app'); // 挂载到 id 为 'app' 的 DOM 元素上
