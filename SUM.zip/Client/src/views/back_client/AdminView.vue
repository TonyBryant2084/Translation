<template>
  <div class="dashboard-container">
    <el-container style="height: 100vh; border: 1px solid #eee">
      <!-- 头部 -->
      <el-header class="header">
        <span class="header-title">旅译通后台管理系统</span>
      </el-header>

      <el-container>
        <!-- 侧边栏 -->
        <el-aside class="sidebar">
          <el-menu
            :default-openeds="['1']"
            class="el-menu-vertical-demo"
            background-color="#fff"
            text-color="#333"
            active-text-color="#409EFF"
          >
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-s-tools"></i>
                <span>系统信息管理</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="1-1">
                  <router-link to="/bachome" class="menu-link"
                    >首页</router-link
                  >
                </el-menu-item>
                <el-menu-item index="1-2">
                  <router-link to="/about" class="menu-link"
                    >信息管理</router-link
                  >
                </el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </el-aside>

        <!-- 主内容区 -->
        <el-main class="main-content">
          <!-- 表单 -->
          <el-form :inline="true" :model="formInline" class="search-form">
            <el-form-item label="用户名">
              <el-input
                v-model="formInline.username"
                placeholder="请输入username"
                clearable
              />
            </el-form-item>
            <el-form-item>
              <el-button type="primary" @click="onSubmit">查询</el-button>
            </el-form-item>
          </el-form>

          <!-- 表格 -->
          <el-table
            :data="tableData"
            border
            stripe
            class="data-table"
            :row-class-name="rowClassName"
          >
            <el-table-column prop="username" label="用户名" width="120" />
            <el-table-column prop="user_pic" label="图片" width="120">
              <template slot-scope="scope">
                <img
                  v-if="scope.row.user_pic"
                  :src="scope.row.user_pic"
                  alt="用户图片"
                  style="width: 50px; height: 50px; border-radius: 50%"
                />
                <span v-else>无图片</span>
              </template>
            </el-table-column>
            <el-table-column prop="nickname" label="昵称" width="120">
              <template slot-scope="scope">
                {{ scope.row.nickname || "无昵称" }}
              </template>
            </el-table-column>
            <el-table-column prop="gender" label="性别" width="120">
              <template slot-scope="scope">
                {{ scope.row.gender || "保密" }}
              </template>
            </el-table-column>
            <el-table-column prop="role" label="权限" width="120">
              <template slot-scope="scope">
                {{ scope.row.role === 1 ? "管理员" : "普通用户" }}
              </template>
            </el-table-column>
            <el-table-column prop="email" label="邮箱">
              <template slot-scope="scope">
                {{ scope.row.email || "无邮箱" }}
              </template>
            </el-table-column>
            <el-table-column label="操作">
              <template slot-scope="scope">
                <el-button type="danger" @click="confirmDelete(scope.row)">
                  删除
                </el-button>
              </template>
            </el-table-column>
          </el-table>

          <!-- 分页 -->
          <el-pagination
            class="pagination"
            background
            layout="total, sizes, prev, pager, next, jumper"
            :total="total"
            :page-size="pageSize"
            :current-page="currentPage"
            :page-sizes="[5, 10, 20, 50]"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </el-main>
      </el-container>
    </el-container>

    <!-- 确认删除弹窗 -->
    <el-dialog
      title="提示"
      :visible.sync="deleteDialogVisible"
      width="30%"
      :before-close="handleClose"
    >
      <span>确定要删除用户 {{ deleteUsername }} 吗？</span>
      <span slot="footer" class="dialog-footer">
        <el-button @click="deleteDialogVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleDelete">确 定</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import axios from "@/api/axios";

export default {
  data() {
    return {
      allData: [], // 所有的数据
      tableData: [], // 表格显示的数据
      formInline: {
        username: "", // 用户名
      },
      highlightedId: null, // 高亮的用户ID
      total: 0, // 数据总数
      pageSize: 5, // 每页显示的条目数
      currentPage: 1, // 当前页码
      deleteDialogVisible: false, // 控制删除弹窗的显示状态
      deleteUsername: "", // 要删除的用户名
      deleteId: null, // 要删除的用户ID
    };
  },
  computed: {
    // 计算分页数据
    pagedData() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = start + this.pageSize;
      return this.allData.slice(start, end); // 获取当前页的数据
    },
  },
  methods: {
    // 查询用户
    onSubmit() {
      const user = this.formInline.username.trim();
      if (!user) {
        this.$message.warning("请输入用户名！");
        return;
      }

      // 查找匹配的用户
      const foundUser = this.allData.find((item) => item.username === user);

      if (foundUser) {
        // 计算匹配用户所在的页码
        this.currentPage = Math.ceil(
          (this.allData.indexOf(foundUser) + 1) / this.pageSize
        );
        this.highlightedId = foundUser.id; // 设置高亮ID
        this.updateTableData(); // 更新表格数据
      } else {
        this.$message.error("未找到该用户！");
      }
    },
    // 高亮行样式
    rowClassName({ row }) {
      return row.id === this.highlightedId ? "highlight-row" : "";
    },
    // 更新表格数据
    updateTableData() {
      const start = (this.currentPage - 1) * this.pageSize;
      const end = start + this.pageSize;
      this.tableData = this.allData.slice(start, end);
    },
    // 处理每页条数变化
    handleSizeChange(size) {
      this.pageSize = size;
      this.currentPage = 1; // 重新从第一页开始
      this.updateTableData();
    },
    // 处理当前页变化
    handleCurrentChange(page) {
      this.currentPage = page;
      this.updateTableData();
    },
    // 获取数据
    async fetchData() {
      try {
        const response = await axios.get("http://127.0.0.1:80/my/show", {
          headers: {
            Authorization: `${localStorage.getItem("token")}`,
          },
        });
        if (response.data.status === 0) {
          this.allData = response.data.data; // 存储所有数据
          this.total = this.allData.length; // 更新数据总条数
          this.updateTableData(); // 更新当前页数据
        } else {
          console.error("获取数据失败:", response.data.msg);
        }
      } catch (error) {
        console.error("请求失败:", error);
      }
    },
    // 确认删除用户
    confirmDelete(row) {
      this.deleteUsername = row.username; // 获取要删除的用户名
      this.deleteDialogVisible = true; // 显示删除确认弹窗
    },
    // 执行删除操作
    async handleDelete() {
      try {
        const response = await axios.post(
          "http://127.0.0.1:80/my/delete",
          {
            username: this.deleteUsername,
          },
          {
            headers: {
              Authorization: `${localStorage.getItem("token")}`,
            },
          }
        );
        if (response.data.status === 0) {
          this.$message.success("删除成功！");
          this.fetchData(); // 重新获取数据
        } else {
          this.$message.error("删除失败：" + response.data.msg);
        }
      } catch (error) {
        this.$message.error("删除失败：" + error.message);
      } finally {
        this.deleteDialogVisible = false; // 关闭删除弹窗
      }
    },
    // 关闭删除确认弹窗
    handleClose(done) {
      this.$confirm("确认关闭？")
        .then(() => {
          done();
        })
        .catch(() => {});
    },
  },
  // 组件挂载完成后获取数据
  async mounted() {
    this.fetchData();
  },
};
</script>

<style scoped>
.dashboard-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

.header {
  background-color: rgb(238, 241, 246);
  display: flex;
  align-items: center;
  padding: 0 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
}

.header-title {
  font-size: 24px;
  font-weight: bold;
  color: #409eff;
}

.sidebar {
  border-right: 1px solid #eee;
  background-color: #fff;
}

.main-content {
  background-color: #f5f7fa;
  padding: 20px;
}

.search-form {
  margin-bottom: 20px;
}

.data-table {
  width: 100%;
  margin-bottom: 20px;
}

.pagination {
  text-align: right;
  margin-top: 20px;
}

.menu-link {
  text-decoration: none;
  color: inherit;
}

/* 高亮行 */
.highlight-row {
  background-color: #f4f7fc !important;
}

/* 删除确认弹窗 */
.dialog-footer {
  text-align: right;
}
</style>
