<template>
  <div id="profile">
    <!-- 顶部导航栏 -->
    <el-menu
      :default-active="activeIndex"
      class="nav-bar"
      mode="horizontal"
      background-color="#2c6eb3"
      text-color="#fff"
      active-text-color="#ff8c1a"
    >
      <el-menu-item index="1">
        <span class="menu-item">
          <span class="cn-text">旅译通 / 旅译通</span>
        </span>
      </el-menu-item>
      <el-menu-item index="2">
        <span class="menu-item">
          <router-link to="/" style="text-decoration: none">
            首页 / ホーム</router-link
          >
        </span>
      </el-menu-item>
        <el-menu-item index="3">
          <span class="menu-item">
            <span class="cn-text">
              <router-link to="/recommend" style="text-decoration: none">推荐景点 / おすすめスポットです</router-link>
            </span>
          </span>
        </el-menu-item>
      <el-menu-item index="4">
        <span class="menu-item">
          <span class="cn-text">
            <router-link to="/translate" style="text-decoration: none">
              翻译/翻訳</router-link
            >
          </span>
        </span>
      </el-menu-item>
      <el-menu-item index="5">
        <span class="menu-item">
          <span class="cn-text">
            <router-link to="/map" style="text-decoration: none">
              地图/地図</router-link
            >
          </span>
        </span>
      </el-menu-item>
      <el-menu-item index="6">
        <span class="menu-item">
          <span class="cn-text">
            <router-link to="/user" style="text-decoration: none">
              个人管理</router-link
            >
          </span>
        </span>
      </el-menu-item>
    </el-menu>

    <!-- 主内容区域 -->
    <el-container
      style="height: 90vh; display: flex; margin: 0; overflow-x: hidden"
    >
      <el-container
        style="
          flex-grow: 1;
          display: flex;
          flex-direction: column;
          padding: 20px;
        "
      >
        <el-header
          style="
            text-align: center;
            font-size: 20px;
            line-height: 40px;
            height: 40px;
            background-color: #409eff;
            color: #fff;
            border-radius: 10px;
          "
        >
          个人资料
        </el-header>

        <el-main
          style="
            flex-grow: 1;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
            border-radius: 10px;
          "
        >
          <el-form label-width="100px">
            <el-form-item label="昵称" style="margin-bottom: 30px">
              <el-input v-model="user.nickname"></el-input>
            </el-form-item>
            <el-form-item label="邮箱" style="margin-bottom: 30px">
              <el-input v-model="user.email"></el-input>
            </el-form-item>
            <el-form-item label="性别" style="margin-bottom: 30px">
              <el-radio-group v-model="user.gender">
                <el-radio-button label="男">男</el-radio-button>
                <el-radio-button label="女">女</el-radio-button>
              </el-radio-group>
            </el-form-item>
            <el-form-item label="头像" style="margin-bottom: 30px">
              <el-upload
                class="avatar-uploader"
                action="https://your-api.com/api/user/avatar"
                :show-file-list="false"
                :on-success="handleAvatarSuccess"
                :before-upload="beforeAvatarUpload"
              >
                <img v-if="user.avatar" :src="user.avatar" class="avatar" />
                <i v-else class="el-icon-plus avatar-uploader-icon"></i>
              </el-upload>
            </el-form-item>
            <el-form-item
              style="
                display: flex;
                justify-content: space-between;
                margin-top: 40px;
              "
            >
              <el-button type="primary" @click="saveProfile">保存</el-button>
              <el-button type="danger" @click="showChangePasswordDialog = true">
                修改密码</el-button
              >
              <el-button type="warning" @click="logout">退出登录</el-button>
            </el-form-item>
          </el-form>
        </el-main>
      </el-container>
    </el-container>

    <!-- 修改密码对话框 -->
    <el-dialog
      title="修改密码"
      :visible.sync="showChangePasswordDialog"
      width="30%"
      center
    >
      <el-form label-width="100px">
        <el-form-item label="原密码">
          <el-input
            type="password"
            v-model="oldPassword"
            placeholder="请输入原密码"
          ></el-input>
        </el-form-item>
        <el-form-item label="新密码">
          <el-input
            type="password"
            v-model="newPassword"
            placeholder="请输入新密码"
          ></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="showChangePasswordDialog = false">取消</el-button>
        <el-button type="primary" @click="changePassword">保存</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script>
import axios from "@/api/axios";

export default {
  data() {
    return {
      activeIndex: "1", // 默认选中的菜单项
      user: {
        nickname: "",
        email: "",
        gender: "",
        avatar: "",
      },
      showChangePasswordDialog: false,
      oldPassword: "",
      newPassword: "",
    };
  },
  created() {
    this.fetchUserProfile();
  },
  methods: {
    // 获取用户资料
    async fetchUserProfile() {
      try {
        const response = await axios.get("http://127.0.0.1:80/my/userinfo", {
          headers: { Authorization: ` ${localStorage.getItem("token")}` },
        });

        if (response.data.status === 0) {
          const userData = response.data.data;
          this.user = {
            nickname: userData.nickname || "",
            email: userData.email || "",
            gender: userData.gender || "", // 假设性别信息不在后端返回的数据中
            avatar: userData.user_pic || "",
          };
          console.log(this.user.avatar);
        } else {
          this.$message.error(response.data.msg || "无法获取用户信息");
        }
      } catch (error) {
        this.$message.error("无法获取用户信息，请稍后重试");
      }
    },

    // 保存个人资料
    async saveProfile() {
      try {
        const response = await axios.post("http://127.0.0.1:80/my/userinfo", {
          nickname: this.user.nickname,
          gender: this.user.gender,
          email: this.user.email,
        });

        if (response.data.status === 0) {
          this.$message.success("个人资料已保存！");
        } else {
          this.$message.error(response.data.msg || "更新资料失败");
        }
      } catch (error) {
        this.$message.error("更新资料失败，请稍后重试");
      }
    },

    // 头像上传成功处理
    handleAvatarSuccess(response) {
      if (response.status === 0) {
        this.user.avatar = response.data.user_pic;
        this.$message.success("头像上传成功！");
      } else {
        this.$message.error(response.msg || "头像上传失败");
      }
    },

    // 上传头像前检查
    beforeAvatarUpload(file) {
      const isJPG = file.type === "image/jpeg";
      const isPNG = file.type === "image/png";
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG && !isPNG) {
        this.$message.error("上传头像图片只能是 JPG 或 PNG 格式!");
        return false;
      }
      if (!isLt2M) {
        this.$message.error("上传头像图片大小不能超过 2MB!");
        return false;
      }
      return true;
    },

    // 修改密码
    async changePassword() {
      if (!this.oldPassword || !this.newPassword) {
        return this.$message.error("请输入原密码和新密码！");
      }

      try {
        const response = await axios.post(
          "http://127.0.0.1:80/my/updatepwd",
          {
            oldPwd: this.oldPassword,
            newPwd: this.newPassword,
          },
          {
            headers: { Authorization: `${localStorage.getItem("token")}` },
          }
        );

        if (response.data.status === 0) {
          this.$message.success("密码修改成功！");
          this.showChangePasswordDialog = false;
        } else {
          this.$message.error(response.data.msg || "修改失败");
        }
      } catch (error) {
        this.$message.error("修改密码失败，请稍后重试");
      }
    },

    // 退出登录
    logout() {
      localStorage.removeItem("token");
      this.$message.success("已退出登录");
      this.$router.push("/login");
    },
  },
};
</script>

<style scoped>
.nav-bar {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000; /* 确保导航栏在最上层 */
}

.main-content {
  margin-top: 60px; /* 给主内容区域留出导航栏的高度 */
}

.avatar-uploader .avatar {
  width: 100px;
  height: 100px;
  border-radius: 50%;
  display: block;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  width: 100px;
  height: 100px;
  text-align: center;
  line-height: 100px;
  border: 1px dashed #d9d9d9;
  border-radius: 50%;
}
</style>