<template>
  <div class="app-container">
    <!-- 顶部导航栏 -->
    <el-menu
      :default-active="activeIndex"
      class="nav-bar"
      mode="horizontal"
      background-color="#2c6eb3"
      text-color="#fff"
      active-text-color="#ff8c1a"
    >
      <el-menu-item index="1">
        <span class="menu-item">
          <span class="cn-text">旅译通 / 旅译通</span>
        </span>
      </el-menu-item>
      <el-menu-item index="2">
        <span class="menu-item">
          <router-link to="/" style="text-decoration: none"
            >首页 / ホーム</router-link
          >
        </span>
      </el-menu-item>
      <el-menu-item index="3">
        <span class="menu-item">
          <router-link to="/recommend" style="text-decoration: none"
            >推荐景点 / おすすめスポットです</router-link
          >
        </span>
      </el-menu-item>
      <el-menu-item index="4">
        <span class="menu-item">
          <router-link to="/translate" style="text-decoration: none"
            >翻译/翻訳</router-link
          >
        </span>
      </el-menu-item>
      <el-menu-item index="5">
        <span class="menu-item">
          <router-link to="/map" style="text-decoration: none"
            >地图/地図</router-link
          >
        </span>
      </el-menu-item>
      <el-menu-item index="6">
        <span class="menu-item">
          <router-link to="/user" style="text-decoration: none"
            >个人管理</router-link
          >
        </span>
      </el-menu-item>
    </el-menu>

    <div class="main-content">
      <!-- 翻译区域 -->
      <el-row :gutter="20" style="flex: 4">
        <el-card class="translation-card">
          <div class="translation-header">
            <h2>即时翻译 / 即時翻訳</h2>
          </div>
          <div class="translation-result">
            <p>{{ translationResult }}</p>
          </div>
        </el-card>
      </el-row>

      <!-- 输入和操作区域 -->
      <el-row :gutter="20" style="flex: 3">
        <el-card class="input-card">
          <div class="input-section">
            <!-- 源语言和目标语言选择框 -->
            <div class="language-selectors">
              <el-select
                v-model="sourceLanguage"
                placeholder="选择源语言 / 元の言語を選択"
                class="language-selector"
              >
                <el-option label="自动检测 / 自動検出" value="auto"></el-option>
                <el-option label="中文 / 中国語" value="zh"></el-option>
                <el-option label="日语 / 日本語" value="jp"></el-option>
              </el-select>
              <el-select
                v-model="targetLanguage"
                placeholder="选择目标语言 / 目標言語を選択"
                class="language-selector"
              >
                <el-option label="自动检测 / 自動検出" value="auto"></el-option>
                <el-option label="中文 / 中国語" value="zh"></el-option>
                <el-option label="日语 / 日本語" value="jp"></el-option>
              </el-select>
            </div>

            <!-- 输入框 -->
            <el-input
              type="textarea"
              :rows="4"
              placeholder="请输入需要翻译的内容 / 翻訳したい内容を入力してください"
              v-model="textarea"
              class="textarea-input"
            ></el-input>

            <!-- 按钮区域 -->
            <div class="action-buttons">
              <el-button type="primary" @click="submitTranslation"
                >提交翻译 / 翻訳を提出</el-button
              >
              <el-button
                type="primary"
                @click="startSpeechRecognition"
                :disabled="isRecording"
                >开始录音 / 録音を開始</el-button
              >
              <el-button
                type="danger"
                @click="stopSpeechRecognition"
                :disabled="!isRecording"
                >结束录音 / 録音を終了</el-button
              >
              <el-button type="primary" @click="selectImage"
                >图片翻译 / 画像翻訳</el-button
              >
              <!-- 隐藏的文件输入框 -->
              <input
                type="file"
                ref="fileInput"
                accept="image/*"
                @change="handleImageUpload"
                style="display: none"
              />
            </div>
          </div>
        </el-card>
      </el-row>
    </div>
  </div>
</template>

<script>
import axios from "axios";
import md5 from "js-md5";
import Tesseract from "tesseract.js";

export default {
  data() {
    return {
      activeIndex: "4", // 默认选中翻译菜单项
      textarea: "",
      sourceLanguage: "auto",
      targetLanguage: "jp",
      translationResult:
        "翻译结果将显示在这里... / 翻訳結果はここに表示されます...",
      appId: "20250227002286666",
      secretKey: "RUtkbgtop5XgEQUxIiGB",
      isRecording: false, // 标识是否正在录音
      recognition: null, // SpeechRecognition 实例
      silenceTimeout: null, // 静音检测超时 ID
    };
  },
  methods: {
    // 提交文本翻译
    submitTranslation() {
      if (this.textarea) {
        const salt = Math.random().toString(36).substr(2, 16);
        const sign = md5(this.appId + this.textarea + salt + this.secretKey);

        axios
          .get("/api/api/trans/vip/translate", {
            params: {
              q: this.textarea,
              from: this.sourceLanguage,
              to: this.targetLanguage,
              appid: this.appId,
              salt: salt,
              sign: sign,
            },
          })
          .then((response) => {
            if (response.data.trans_result) {
              this.translationResult = response.data.trans_result[0].dst;
            } else {
              const errorMsg =
                response.data.error_msg || "未知错误 / 未知のエラー";
              console.error("翻译失败原因 / 翻訳失敗の理由:", errorMsg);
              this.translationResult = `翻译失败: ${errorMsg} / 翻訳失敗: ${errorMsg}`;
            }
          })
          .catch((error) => {
            console.error("翻译请求出错 / 翻訳リクエストエラー:", error);
            this.translationResult =
              "翻译请求出错，请检查网络或稍后重试 / 翻訳リクエストエラー、ネットワークを確認するか、後で再試行してください";
          });
      }
    },

    // 开始语音识别
    startSpeechRecognition() {
      const SpeechRecognition =
        window.SpeechRecognition || window.webkitSpeechRecognition;

      if (!SpeechRecognition) {
        alert(
          "您的浏览器不支持语音识别功能 / あなたのブラウザは音声認識機能をサポートしていません。Chromeを使用してください。"
        );
        return;
      }

      // 初始化语音识别
      this.recognition = new SpeechRecognition();
      const languageMap = {
        zh: "zh-CN",
        jp: "ja-JP",
        en: "en-US",
      };
      this.recognition.lang = languageMap[this.sourceLanguage] || "zh-CN";
      this.recognition.continuous = true; // 设置为连续识别
      this.recognition.interimResults = true; // 启用中间结果

      // 识别开始
      this.recognition.onstart = () => {
        this.isRecording = true;
        this.translationResult =
          "正在聆听，请开始说话... / 聞いています、話し始めてください...";
      };

      // 识别结果
      this.recognition.onresult = (event) => {
        let finalTranscript = "";
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += transcript + " ";
          }
        }
        this.textarea = finalTranscript.trim();

        // 检测静音
        if (finalTranscript) {
          clearTimeout(this.silenceTimeout); // 清除之前的静音检测
          this.silenceTimeout = setTimeout(() => {
            this.stopSpeechRecognition(); // 静音超过 2 秒后停止识别
          }, 2000); // 2 秒静音检测
        }
      };

      // 识别结束
      this.recognition.onend = () => {
        this.isRecording = false;
        this.translationResult = "语音识别结束 / 音声認識が終了しました";
      };

      // 识别错误
      this.recognition.onerror = (event) => {
        console.error("语音识别出错:", event.error);
        this.translationResult =
          "语音识别失败，请检查麦克风权限或尝试重新输入 / 音声認識に失敗しました。マイクの許可を確認するか、再試行してください";
        this.isRecording = false;
      };

      // 开始识别
      this.recognition.start();
    },

    // 停止语音识别
    stopSpeechRecognition() {
      if (this.recognition) {
        this.recognition.stop();
        this.isRecording = false;
        this.translationResult = "录音已停止 / 録音を停止しました";
      }
    },

    // 打开图片翻译对话框
    selectImage() {
      this.$refs.fileInput.click();
    },

    // 处理图片上传
    handleImageUpload(event) {
      const file = event.target.files[0];
      if (file) {
        this.ocrRecognize(file);
      }
    },

    // OCR 识别
    ocrRecognize(file) {
      Tesseract.recognize(
        file,
        this.sourceLanguage === "zh" ? "chi_sim" : "jpn", // 自动设置语言
        {
          logger: (m) => console.log(m),
        }
      )
        .then(({ data: { text } }) => {
          this.textarea = text;
          this.translationResult =
            "图片文字识别成功，请提交翻译 / 画像文字の認識に成功しました。翻訳を提出してください";
        })
        .catch((error) => {
          console.error("OCR 识别失败:", error);
          this.translationResult =
            "图片文字识别失败，请重试 / 画像文字の認識に失敗しました。再試行してください";
        });
    },
  },
};
</script>

<style scoped>
.app-container {
  text-align: center;
  font-family: Arial, sans-serif;
}

.nav-bar {
  font-size: 18px;
}

.main-content {
  padding: 20px;
}

.translation-card,
.input-card {
  margin-bottom: 20px;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  border-radius: 8px;
  background-color: #fff;
}

.translation-header {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #2c6eb3;
}

.translation-result {
  font-size: 18px;
  color: #333;
  padding: 20px;
  background-color: #f9f9f9;
  border-radius: 8px;
  min-height: 100px;
  white-space: pre-wrap;
  word-wrap: break-word;
}

.input-section {
  padding: 20px;
}

.language-selectors {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}

.language-selector {
  width: 100%;
}

.textarea-input {
  margin-bottom: 20px;
}

.action-buttons {
  display: flex;
  gap: 10px;
  margin-top: 20px;
}

.el-button {
  flex-grow: 1;
  font-size: 16px;
  height: 40px;
}
</style>