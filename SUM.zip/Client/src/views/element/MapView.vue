<template>
  <div class="app-container">
    <!-- 顶部导航栏 -->
    <el-menu
      :default-active="activeIndex"
      class="nav-bar"
      mode="horizontal"
      background-color="#2c6eb3"
      text-color="#fff"
      active-text-color="#ff8c1a"
    >
      <el-menu-item index="1">
        <span class="menu-item">
          <span class="cn-text">旅译通 / 旅译通</span>
        </span>
      </el-menu-item>
      <el-menu-item index="2">
        <span class="menu-item">
          <span class="cn-text">
            <router-link to="/" style="text-decoration: none">
              首页 / ホーム</router-link
            >
          </span>
        </span>
      </el-menu-item>
      <el-menu-item index="3">
        <span class="menu-item">
          <span class="cn-text">推荐景点 / おすすめスポットです</span>
        </span>
      </el-menu-item>
      <el-menu-item index="4">
        <span class="menu-item">
          <router-link to="/translate" style="text-decoration: none">
            翻译/翻訳
          </router-link>
        </span>
      </el-menu-item>
      <el-menu-item index="5">
        <span class="menu-item">
          <router-link to="/map" style="text-decoration: none">
            地图/地図
          </router-link>
        </span>
      </el-menu-item>
      <el-menu-item index="6">
        <span class="menu-item">
          <router-link to="/user" style="text-decoration: none">
            个人管理
          </router-link>
        </span>
      </el-menu-item>
    </el-menu>

    <!-- 地图展示区域 -->
    <div class="map-container">
      <el-card class="map-card">
        <baidu-map
          class="map"
          :center="mapCenter"
          :zoom="zoom"
          ref="baiduMap"
          @ready="onMapLoaded"
        >
          <bm-view class="map"></bm-view>
          <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>
          <bm-map-type
            :map-types="['BMAP_NORMAL_MAP', 'BMAP_HYBRID_MAP']"
            anchor="BMAP_ANCHOR_TOP_LEFT"
          ></bm-map-type>
          <bm-marker
            :position="markerPosition"
            :dragging="true"
            @dragend="handleMarkerDragEnd"
          ></bm-marker>
          <bm-driving
            v-if="showRoute && routeType === 'driving'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            :policy="routePolicy"
            @searchcomplete="onRouteComplete"
          ></bm-driving>
          <bm-transit
            v-if="showRoute && routeType === 'transit'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            @searchcomplete="onRouteComplete"
          ></bm-transit>
          <bm-walking
            v-if="showRoute && routeType === 'walking'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            @searchcomplete="onRouteComplete"
          ></bm-walking>
        </baidu-map>
      </el-card>
    </div>

    <!-- 搜索框 -->
    <div
      style="
        padding: 10px 20px;
        width: 100%;
        background-color: #fff;
        box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
        box-sizing: border-box;
        position: fixed;
        bottom: 80px;
        z-index: 1000;
      "
    >
      <div
        style="
          display: flex;
          align-items: center;
          margin-bottom: 10px;
          width: 100%;
          box-sizing: border-box;
        "
      >
        <el-input
          v-model="searchQuery"
          placeholder="请输入地点名称"
          style="
            flex-grow: 1;
            margin-right: 10px;
            font-size: 16px;
            border-radius: 6px;
            box-shadow: 0px 2px 5px rgba(0, 0, 0, 0.1);
          "
        ></el-input>
        <el-button
          type="primary"
          style="font-size: 16px; padding: 10px"
          @click="searchLocation"
        >
          搜索
        </el-button>
      </div>
    </div>

    <!-- 定位到当前位置按钮 -->
    <div class="locate-btn-container">
      <el-button
        type="primary"
        style="flex-grow: 1; font-size: 16px; padding: 10px"
        @click="locateCurrentPosition"
      >
        定位到当前位置
      </el-button>
    </div>
  </div>
</template>

<script>
export default {
  name: "MapView",
  data() {
    return {
      mapCenter: { lng: 114.305, lat: 30.592 }, // 默认地图中心点为武汉
      zoom: 15, // 缩放级别
      markerPosition: { lng: 114.305, lat: 30.592 }, // 标记点位置
      previousMarkerPosition: null, // 上一次的标记点位置
      searchQuery: "", // 搜索框内容
      routeStart: "", // 路线起点（地址字符串）
      routeEnd: "", // 路线终点（地址字符串）
      routeStartPoint: null, // 路线起点（经纬度）
      routeEndPoint: null, // 路线终点（经纬度）
      showRoute: false, // 是否显示路线
      routeType: "driving", // 导航模式（driving: 自驾, transit: 公交地铁, walking: 步行）
      routePolicy: "BMAP_DRIVING_POLICY_LEAST_TIME", // 自驾路线规划策略
      mapLoaded: false, // 地图加载状态
      watchPositionId: null, // 实时位置监听的 ID
      routeInfo: null, // 导航路线信息
      showPOIDialog: false, // 是否显示 POI 详情弹窗
      selectedPOI: null, // 当前选中的 POI
      searchType: "景点", // POI 搜索类型
    };
  },
  mounted() {
    // 确保百度地图 API 已加载
    /* global BMap */
    if (window.BMap) {
      this.onMapLoaded();
    } else {
      // 如果百度地图 API 未加载完成，等待一段时间后重试
      const checkBaiduMap = setInterval(() => {
        if (window.BMap) {
          clearInterval(checkBaiduMap);
          this.onMapLoaded();
        }
      }, 100);
    }
  },
  methods: {
    // 地图加载完成事件
    onMapLoaded() {
      this.mapLoaded = true;
      console.log("地图加载完毕，可以搜索");

      // 添加 POI 点击事件监听
      const mapInstance = this.$refs.baiduMap.map;
      mapInstance.addEventListener("click", this.handleMapClick);
    },

    // 处理地图点击事件
    handleMapClick(e) {
      const mapInstance = this.$refs.baiduMap.map;
      const point = e.point;

      console.log("地图点击事件触发，点击位置:", point);

      // 确保 mapInstance 存在
      if (!mapInstance) {
        console.error("百度地图实例未初始化");
        return;
      }

      // 初始化 POI 搜索
      const localSearch = new BMap.LocalSearch(mapInstance, {
        renderOptions: { map: mapInstance },
        pageCapacity: 10, // 限制返回的 POI 数量
        enableAutoViewport: true, // 自动调整视角
        onSearchComplete: (results) => {
          console.log("搜索完成，搜索结果:", results);

          if (
            results &&
            typeof results.getCurrentNumPois === "function" &&
            results.getCurrentNumPois() > 0
          ) {
            const poi = results.getPoi(0);
            if (poi) {
              this.selectedPOI = {
                name: poi.title,
                address: poi.address || "暂无地址信息",
                point: poi.point,
              };
              this.showPOIDialog = true;
              console.log("找到 POI:", this.selectedPOI);
            } else {
              console.warn("未找到有效 POI 数据");
            }
          } else {
            console.warn("未找到相关 POI");
          }
        },
        onSearchError: (error) => {
          console.error("搜索失败:", error);
        },
      });

      // 搜索点击位置附近的 POI
      console.log("开始搜索 POI");
      localSearch.searchNearby("景点", point, 100000); // 附近 500m 搜索“景点”
    },

    // 搜索地点
    searchLocation() {
      if (this.searchQuery.trim() === "") {
        this.$message.warning("请输入地点名称");
        return;
      }

      // 确保地图实例已经加载
      const mapInstance = this.$refs.baiduMap.map;
      if (!mapInstance) {
        this.$message.warning("地图尚未加载");
        return;
      }

      // 执行地点搜索
      if (window.BMap && window.BMap.LocalSearch) {
        const localSearch = new window.BMap.LocalSearch(mapInstance, {
          onSearchComplete: (results) => {
            if (results && results.getNumPois() > 0) {
              const firstResult = results.getPoi(0);
              this.mapCenter = firstResult.point;
              this.markerPosition = firstResult.point;
            } else {
              this.$message.error("未找到相关地点");
            }
          },
        });

        localSearch.search(this.searchQuery);
      } else {
        this.$message.error("百度地图 API 加载失败");
      }
    },

    // 定位当前位置
    locateCurrentPosition() {
      // 直接设置地图中心点和标记点为指定位置
      this.mapCenter = { lng: 114.27950005987421, lat: 30.774687706210035 };
      this.markerPosition = {
        lng: 114.27950005987421,
        lat: 30.774687706210035,
      };
    },

    // 规划路线
    planRoute() {
      if (!this.routeStart || !this.routeEnd) {
        this.$message.warning("请输入起点和终点");
        return;
      }

      const geocoder = new window.BMap.Geocoder();

      // 解析起点，限制城市为武汉
      geocoder.getPoint(
        this.routeStart,
        (startPoint) => {
          if (!startPoint) {
            this.$message.error("无法解析起点");
            return;
          }

          // 解析终点，限制城市为武汉
          geocoder.getPoint(
            this.routeEnd,
            (endPoint) => {
              if (!endPoint) {
                this.$message.error("无法解析终点");
                return;
              }

              // 设置起点和终点的经纬度
              this.routeStartPoint = startPoint;
              this.routeEndPoint = endPoint;
              this.showRoute = true; // 显示路线

              // 将地图中心点设置为起点
              this.mapCenter = startPoint;
            },
            "武汉市"
          ); // 限制城市为武汉
        },
        "武汉市"
      ); // 限制城市为武汉
    },

    // 从当前位置导航
    startNavigationFromCurrentLocation() {
      if (!this.routeEnd) {
        this.$message.warning("请输入终点");
        return;
      }

      // 获取当前位置
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            this.routeStartPoint = { lng: longitude, lat: latitude }; // 设置起点为当前位置

            // 解析终点，限制城市为武汉
            const geocoder = new window.BMap.Geocoder();
            geocoder.getPoint(
              this.routeEnd,
              (endPoint) => {
                if (!endPoint) {
                  this.$message.error("无法解析终点");
                  return;
                }

                // 设置终点
                this.routeEndPoint = endPoint;
                this.showRoute = true; // 显示路线

                // 开始监听位置变化
                this.startWatchingPosition();
              },
              "武汉市"
            ); // 限制城市为武汉
          },
          (error) => {
            this.$message.error(
              "获取当前位置失败，请检查浏览器权限或手动输入位置"
            );
            console.error("定位失败:", error);
          }
        );
      } else {
        this.$message.error("您的浏览器不支持定位功能");
      }
    },

    // 开始监听位置变化
    startWatchingPosition() {
      if (navigator.geolocation) {
        this.watchPositionId = navigator.geolocation.watchPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            this.routeStartPoint = { lng: longitude, lat: latitude }; // 更新起点为当前位置
            this.mapCenter = { lng: longitude, lat: latitude }; // 更新地图中心点
          },
          (error) => {
            this.$message.error("获取实时位置失败");
            console.error("实时定位失败:", error);
          },
          { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 } // 定位选项
        );
      } else {
        this.$message.error("您的浏览器不支持定位功能");
      }
    },

    // 停止监听位置变化
    stopWatchingPosition() {
      if (this.watchPositionId && navigator.geolocation) {
        navigator.geolocation.clearWatch(this.watchPositionId);
        this.watchPositionId = null;
      }
    },

    // 路线规划完成事件
    onRouteComplete(results) {
      if (results) {
        console.log("路线规划完成", results);
        this.routeInfo = this.parseRouteInfo(results); // 解析并显示路线信息
      } else {
        this.$message.error("路线规划失败");
      }
    },

    // 解析路线信息
    parseRouteInfo(results) {
      const info = {
        time: "",
        distance: "",
        steps: [],
      };

      if (this.routeType === "driving" || this.routeType === "walking") {
        const plan = results.getPlan(0);
        info.time = plan.getDuration(true); // 获取时间
        info.distance = plan.getDistance(true); // 获取距离
      } else if (this.routeType === "transit") {
        const plan = results.getPlan(0);
        info.time = plan.getDuration(true); // 获取时间
        info.distance = plan.getDistance(true); // 获取距离

        // 提取公交地铁的乘车路线信息
        plan.getRoutes().forEach((route) => {
          route.getSteps().forEach((step) => {
            const stepInfo = {
              description: step.getDescription(), // 步骤描述
              lines: [], // 具体的线路信息
            };

            // 提取具体的线路信息（如几号线）
            if (step.getLines) {
              step.getLines().forEach((line) => {
                stepInfo.lines.push(line.title); // 添加线路信息
              });
            }

            info.steps.push(stepInfo);
          });
        });
      }

      return info;
    },

    // 搜索附近的 POI
    searchNearbyPOIs() {
      const mapInstance = this.$refs.baiduMap.map;
      if (!mapInstance) {
        this.$message.warning("地图尚未加载");
        return;
      }

      const localSearch = new BMap.LocalSearch(mapInstance, {
        renderOptions: { map: mapInstance },
        pageCapacity: 10, // 限制返回的 POI 数量
        enableAutoViewport: true, // 自动调整视角
        onSearchComplete: (results) => {
          if (
            results &&
            typeof results.getCurrentNumPois === "function" &&
            results.getCurrentNumPois() > 0
          ) {
            const pois = [];
            for (let i = 0; i < results.getCurrentNumPois(); i++) {
              const poi = results.getPoi(i);
              pois.push({
                name: poi.title,
                address: poi.address || "暂无地址信息",
                point: poi.point,
                type: this.searchType,
                distance: poi.distance || "未知",
                phone: poi.phone || "暂无电话",
                description: poi.description || "暂无简介",
              });
            }
            //this.selectedPOI = pois[0]; // 默认显示第一个 POI
            this.showPOIDialog = false;
          } else {
            this.$message.warning("未找到相关 POI");
          }
        },
        onSearchError: (error) => {
          this.$message.error("搜索失败");
          console.error("POI 搜索失败:", error);
        },
      });

      // 搜索当前地图中心点附近的 POI
      localSearch.searchNearby(this.searchType, this.mapCenter, 1000); // 附近 1km 搜索
    },
  },
  beforeDestroy() {
    // 组件销毁时停止监听位置变化
    this.stopWatchingPosition();
  },
};
</script>

<style scoped>
.app-container {
  font-family: "Arial", sans-serif;
}

.nav-bar {
  border-bottom: 1px solid #ddd;
}

.map-container {
  display: flex;
  justify-content: center;
  padding: 20px;
}

.map-card {
  width: 100%;
  height: 500px;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1);
}

.map {
  width: 100%;
  height: 500px;
  border-radius: 12px;
}

.search-bar {
  display: flex;
  justify-content: center;
  padding: 10px;
}

.search-input {
  width: 70%;
  border-radius: 6px;
}

.search-btn {
  margin-left: 10px;
  border-radius: 6px;
}

/* 定位按钮容器 */
.locate-btn-container {
  position: fixed;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  z-index: 1000; /* 确保按钮在最上层 */
}

/* 定位按钮样式 */
.locate-btn {
  border-radius: 6px;
  padding: 10px 20px;
  font-size: 16px;
  background-color: #2c6eb3; /* 按钮背景颜色 */
  color: #fff; /* 按钮文字颜色 */
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.1); /* 按钮阴影 */
  transition: background-color 0.3s ease; /* 按钮悬停效果 */
}

.locate-btn:hover {
  background-color: #1e4a8e; /* 按钮悬停时的背景颜色 */
}
</style>