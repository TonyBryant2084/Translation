<template>
  <div style="background-color: #f5f5f5; padding: 20px">
    <el-row :gutter="20">
      <el-col
        :span="8"
        v-for="(item, index) in items"
        :key="index"
        @mouseenter="changeImage(index)"
        @mouseleave="resetImage(index)"
      >
        <el-card :body-style="{ padding: '0px' }" class="card">
          <img :src="item.currentImage" class="image" />
          <div class="content">
            <div class="title">
              <span>{{ item.title }}</span>
            </div>
            <div class="description">
              <p>{{ item.description }}</p>
            </div>
          </div>
        </el-card>
      </el-col>
    </el-row>
  </div>
</template>

<script>
export default {
  data() {
    return {
      items: [
        {
          title: "鸟羽 / 鳥羽",
          image: require("@/assets/scene1.jpg"),
          hoverImage: require("@/assets/scene1-hover.jpg"),
          currentImage: require("@/assets/scene1.jpg"),
          description:
            "鸟羽是一个美丽的海滨城市，以其丰富的海洋资源和美丽的风景而著名。这里是一个放松和享受海洋的理想之地。",
        },
        {
          title: "姬路",
          image: require("@/assets/scene2.jpg"),
          hoverImage: require("@/assets/scene2-hover.jpg"),
          currentImage: require("@/assets/scene2.jpg"),
          description:
            "姬路以其雄伟的姬路城而著名，姬路城被联合国教科文组织列为世界遗产，是日本最具代表性的古代城堡之一。",
        },
        {
          title: "京都",
          image: require("@/assets/scene3.jpg"),
          hoverImage: require("@/assets/scene3-hover.jpg"),
          currentImage: require("@/assets/scene3.jpg"),
          description:
            "京都是日本的文化心脏，拥有众多的神社、寺庙和传统茶室。这里保存着丰富的历史遗产，是体验日本古老文化的好地方。",
        },

        // 添加更多项目
      ],
    };
  },
  methods: {
    changeImage(index) {
      this.items[index].currentImage = this.items[index].hoverImage;
    },
    resetImage(index) {
      this.items[index].currentImage = this.items[index].image;
    },
  },
};
</script>

<style scoped>
.image {
  width: 100%;
  height: 200px; /* 固定图片的高度 */
  object-fit: cover;
  transition: transform 0.3s ease-in-out;
}

.el-card {
  border: none;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%; /* 设置卡片高度为100% */
}

.el-row {
  margin-bottom: 20px;
}

.el-col {
  padding: 10px;
}

.el-col:hover {
  transform: scale(1.05);
}

.el-card:hover {
  box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.2);
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.content {
  padding: 14px;
  text-align: center;
  flex-grow: 1; /* 让内容部分适应剩余空间 */
}

.title {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
}

.description {
  font-size: 14px;
  color: #555;
  line-height: 1.5;
}

.el-col {
  display: flex;
  justify-content: center;
}
</style>
