import Vue from 'vue'
import VueRouter from 'vue-router'

// 使用 VueRouter 插件
Vue.use(VueRouter)

// 定义路由配置
const routes = [
  {
    path: '/map', // 路由路径
    name: 'map', // 路由名称
    component: () => import('../views/element/MapView.vue'), // 懒加载组件
    meta: { requiresAuth: true }, // 需要登录才能访问
  },
  {
    path: '/translate',
    name: 'translate',
    component: () => import('../views/element/TranslateView.vue'),
    meta: { requiresAuth: true }, // 需要登录才能访问
  },
  {
    path: '/recommend',
    name: 'recommend',
    component: () => import('../views/element/RecommendView.vue'),
    meta: { requiresAuth: true }, // 需要登录才能访问
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('../views/element/RegisterView.vue'),
  },
  {
    path: '/user',
    name: 'user',
    component: () => import('../views/element/UserView.vue'),
    meta: { requiresAuth: true }, // 需要登录才能访问
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/element/LoginView.vue'),
  },
  {
    path: '/logini',
    name: 'logini',
    component: () => import('../views/back_client/LoginView.vue'),
  },
  {
    path: '/registeri',
    name: 'register1',
    component: () => import('../views/back_client/RegisterView.vue'),
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('../views/back_client/AdminView.vue'),
    meta: { requiresAuth: true, requiresAdmin: true }, // 需要管理员权限才能访问
  },
  {
    path: '/bachome',
    name: 'bachome',
    component: () => import('../views/back_client/HomeView.vue'),
    meta: { requiresAuth: true, requiresAdmin: true }, // 需要管理员权限才能访问
  },
  {
    path: '/',
    name: 'home',
    component: () => import('../views/front/ThemeView.vue'),
  },
  {
    path: '/itinerary/:id',
    name: 'ItineraryDetail',
    component: () => import('../views/front/ItineraryDetail.vue'),
    props: true, // 将路由参数作为 props 传递给组件
  },
];

// 创建 VueRouter 实例
const router = new VueRouter({
  mode: 'history', // 使用 HTML5 History 模式，去掉 URL 中的 #
  routes // 路由配置
})

/**
 *  全局路由守卫
 *  用于控制登录状态及页面访问权限
 */
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token'); // 获取 token
  const role = Number(localStorage.getItem('role')); // 获取 role 值并转换为数字

  // 如果目标路由需要登录权限
  if (to.matched.some((record) => record.meta.requiresAuth)) {
    if (!token) {
      // 如果未登录，重定向到登录页
      next('/login');
    } else {
      // 检查目标路由是否需要管理员权限
      if (to.matched.some((record) => record.meta.requiresAdmin)) {
        if (role === 1) {
          // 如果是管理员，允许访问
          next();
        } else {
          // 如果不是管理员，重定向到登录页面
          next('/logini');
          Vue.prototype.$message.error('权限不足 / 権限が不足しています'); // 提示权限不足
        }
      } else {
        // 如果不需要管理员权限，直接放行
        next();
      }
    }
  } else {
    // 如果目标路由不需要登录权限，直接放行
    next();
  }
});

// 导出路由实例
export default router
