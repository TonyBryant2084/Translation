import Vue from 'vue';
import App from './App.vue';
import router from './router';
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import axios from './api/axios';
Vue.prototype.$axios = axios; // 全局挂载 axios
import BaiduMap from 'vue-baidu-map';
Vue.config.productionTip = false;

Vue.use(ElementUI);
Vue.use(BaiduMap, {
  ak: 'Yy58gHF0Brzs67lH04hHol2hXOOaYIWe', // 替换为你的百度地图API密钥
});
new Vue({
  router,
  render: h => h(App)
}).$mount('#app');
