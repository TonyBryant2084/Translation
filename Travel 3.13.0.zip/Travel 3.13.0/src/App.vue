<template>
  <div>
<!-- <element-view></element-view> -->
 <router-view></router-view>
  </div>
</template>

<script>
// import ElementView from './views/element/TranslateView.vue'
export default {
  components: {},
  data(){
    return{
      message: "Hello"
    }
  },
  methods:{
    
  }
}
</script>




<style>

</style>
