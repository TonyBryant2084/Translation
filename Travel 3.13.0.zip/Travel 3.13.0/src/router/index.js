import Vue from 'vue'
import VueRouter from 'vue-router'

Vue.use(VueRouter)

const routes = [
  {
    path: '/', // 默认页面
    redirect: '/login'
  },
  {
    path: '/map',
    name: 'map',
    component: () => import('../views/element/MapView.vue'),
    meta: { requiresAuth: true } // 需要登录才能访问
  },
  {
    path: '/translate',
    name: 'translate',
    component: () => import('../views/element/TranslateView.vue'),
    meta: { requiresAuth: true } // 需要登录才能访问
  },
  {
    path: '/register',
    name: 'register',
    component: () => import('../views/element/RegisterView.vue')
  },
  {
    path: '/user',
    name: 'user',
    component: () => import('../views/element/UserView.vue')
  },
  {
    path: '/login',
    name: 'login',
    component: () => import('../views/element/LoginView.vue')
  }
]

const router = new VueRouter({
  mode: 'history', // 使用 HTML5 History 模式，去掉 URL 中的 #
  routes
})

/**
 *  全局路由守卫
 * 用于控制登录状态及页面访问权限
 */
router.beforeEach((to, from, next) => {
  const token = localStorage.getItem('token') // 获取 token

  // 如果目标路由需要登录权限
  if (to.matched.some(record => record.meta.requiresAuth)) {
    if (!token) {
      // 未登录，重定向到登录页
      next('/login')
    } else {
      // 已登录，允许访问
      next()
    }
  }
  // 已登录用户访问登录页或注册页，重定向到首页或其他页面
  else if ((to.path === '/login' || to.path === '/register') && token) {
    next('/map') // 重定向到 map 页面
  }
  else {
    // 不需要权限的页面，直接访问
    next()
  }
})

export default router
