<template>
  <div id="app">
    <!-- 外部容器，防止水平滚动 -->
    <el-container style="height: 80vh; display: flex; margin: 0; overflow-x: hidden;">
      <!-- 左侧导航栏 -->
      <el-aside width="200px" style="background-color: #f4f6f9; border-right: 1px solid #ddd; padding: 20px; box-shadow: 2px 0px 5px rgba(0,0,0,0.1);">
        <span style="font-size: 24px; font-weight: bold; display: block; text-align: center; color: #409EFF;">旅译通</span>
        <el-menu :default-openeds="['1', '3']" active-text-color="#409EFF" style="overflow: hidden;">
          <el-submenu index="1">
            <template slot="title">功能菜单</template>
            <el-menu-item-group>
              <el-menu-item index="1-1">
                <router-link to="/translate">即时翻译</router-link>
              </el-menu-item>
              <el-menu-item index="1-2">
                <router-link to="/map">查看地图</router-link>
              </el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-aside>

      <!-- 主内容区域 -->
      <el-container style="flex-grow: 1; display: flex; flex-direction: column; padding: 20px; overflow-x: hidden;">
        <el-header style="text-align: center; font-size: 20px; line-height: 40px; height: 40px; background-color: #409EFF; color: #fff; border-radius: 10px;">
          地图展示
        </el-header>

        <!-- 地图容器 -->
        <el-main style="flex-grow: 1; padding: 0; overflow-y: auto; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 10px;">
          <baidu-map class="map" :center="mapCenter" :zoom="zoom" ref="baiduMap" @ready="onMapLoaded">
            <bm-view class="map"></bm-view>
            <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation> <!-- 缩放控件 -->
            <bm-map-type :map-types="['BMAP_NORMAL_MAP', 'BMAP_HYBRID_MAP']" anchor="BMAP_ANCHOR_TOP_LEFT"></bm-map-type> <!-- 地图类型控件 -->
            <bm-marker :position="markerPosition" :dragging="true" @dragend="handleMarkerDragEnd"></bm-marker> <!-- 标记点 -->
            <bm-driving
              v-if="showRoute && routeType === 'driving'"
              :start="routeStartPoint"
              :end="routeEndPoint"
              :auto-viewport="true"
              :policy="routePolicy"
              @searchcomplete="onRouteComplete"
            ></bm-driving> <!-- 自驾路线 -->
            <bm-transit
              v-if="showRoute && routeType === 'transit'"
              :start="routeStartPoint"
              :end="routeEndPoint"
              :auto-viewport="true"
              @searchcomplete="onRouteComplete"
            ></bm-transit> <!-- 公交地铁路线 -->
            <bm-walking
              v-if="showRoute && routeType === 'walking'"
              :start="routeStartPoint"
              :end="routeEndPoint"
              :auto-viewport="true"
              @searchcomplete="onRouteComplete"
            ></bm-walking> <!-- 步行路线 -->
          </baidu-map>
        </el-main>
      </el-container>
    </el-container>

    <!-- 输入框区域 -->
    <div style="padding: 10px 20px; width: 100%; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box; position: fixed; bottom: 80px; z-index: 1000;">
      <!-- 搜索框 -->
      <div style="display: flex; align-items: center; margin-bottom: 10px; width: 100%; box-sizing: border-box;">
        <el-input
          v-model="searchQuery"
          placeholder="请输入地点名称"
          style="flex-grow: 1; margin-right: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);"
        ></el-input>
        <el-button 
          type="primary" 
          style="font-size: 16px; padding: 10px;" 
          @click="searchLocation">
          搜索
        </el-button>
      </div>

      <!-- 导航输入框 -->
      <div style="display: flex; align-items: center; width: 100%; box-sizing: border-box;">
        <el-input
          v-model="routeStart"
          placeholder="请输入起点"
          style="flex-grow: 1; margin-right: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);"
        ></el-input>
        <el-input
          v-model="routeEnd"
          placeholder="请输入终点"
          style="flex-grow: 1; margin-right: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);"
        ></el-input>
        <el-button 
          type="primary" 
          style="font-size: 16px; padding: 10px;" 
          @click="planRoute">
          规划路线
        </el-button>
      </div>
    </div>

    <!-- 底部按钮区域 -->
    <div style="position: fixed; bottom: 20px; left: 0; right: 0; padding: 20px; background-color: #fff; box-shadow: 0px -2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box;">
      <div style="display: flex; gap: 10px; width: 100%; box-sizing: border-box;">
        <!-- 导航模式选择 -->
        <el-radio-group v-model="routeType" style="flex-grow: 1;">
          <el-radio-button label="driving">自驾</el-radio-button>
          <el-radio-button label="transit">公交地铁</el-radio-button>
          <el-radio-button label="walking">步行</el-radio-button>
        </el-radio-group>

        <!-- 从当前位置导航 -->
        <el-button 
          type="primary" 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="startNavigationFromCurrentLocation">
          从当前位置导航
        </el-button>

        <!-- 清除标记按钮 -->
        <el-button 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="clearMarker">
          清除标记
        </el-button>
      </div>
    </div>

    <!-- 导航路线信息 -->
    <div v-if="routeInfo" style="position: fixed; top: 320px; right: 20px; padding: 20px; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box; z-index: 1000;">
      <h3 style="margin-bottom: 10px;">导航路线信息</h3>
      <div v-if="routeType === 'driving'">
        <p><strong>时间:</strong> {{ routeInfo.time }}</p>
        <p><strong>路程:</strong> {{ routeInfo.distance }}</p>
      </div>
      <div v-if="routeType === 'transit'">
        <p><strong>时间:</strong> {{ routeInfo.time }}</p>
        <p><strong>路程:</strong> {{ routeInfo.distance }}</p>
        
        <ul>
          <li v-for="(step, index) in routeInfo.steps" :key="index">
            {{ step.description }}
            <span v-if="step.lines && step.lines.length">（{{ step.lines.join(' → ') }}）</span>
          </li>
        </ul>
      </div>
      <div v-if="routeType === 'walking'">
        <p><strong>时间:</strong> {{ routeInfo.time }}</p>
        <p><strong>路程:</strong> {{ routeInfo.distance }}</p>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'MapView',
  data() {
    return {
      mapCenter: { lng: 114.305, lat: 30.592 }, // 默认地图中心点为武汉
      zoom: 15, // 缩放级别
      markerPosition: { lng: 114.305, lat: 30.592 }, // 标记点位置
      previousMarkerPosition: null, // 上一次的标记点位置
      searchQuery: '', // 搜索框内容
      routeStart: '', // 路线起点（地址字符串）
      routeEnd: '', // 路线终点（地址字符串）
      routeStartPoint: null, // 路线起点（经纬度）
      routeEndPoint: null, // 路线终点（经纬度）
      showRoute: false, // 是否显示路线
      routeType: 'driving', // 导航模式（driving: 自驾, transit: 公交地铁, walking: 步行）
      routePolicy: 'BMAP_DRIVING_POLICY_LEAST_TIME', // 自驾路线规划策略
      mapLoaded: false, // 地图加载状态
      watchPositionId: null, // 实时位置监听的 ID
      routeInfo: null, // 导航路线信息
    };
  },
  mounted() {
    // 确保百度地图 API 已加载
    if (window.BMap) {
      this.onMapLoaded();
    } else {
      // 如果百度地图 API 未加载完成，等待一段时间后重试
      const checkBaiduMap = setInterval(() => {
        if (window.BMap) {
          clearInterval(checkBaiduMap);
          this.onMapLoaded();
        }
      }, 100);
    }
  },
  methods: {
    // 地图加载完成事件
    onMapLoaded() {
      this.mapLoaded = true;
      console.log("地图加载完毕，可以搜索");
    },

    // 搜索地点
    searchLocation() {
      if (this.searchQuery.trim() === '') {
        this.$message.warning('请输入地点名称');
        return;
      }

      // 确保地图实例已经加载
      const mapInstance = this.$refs.baiduMap.map;
      if (!mapInstance) {
        this.$message.warning('地图尚未加载');
        return;
      }

      // 执行地点搜索
      if (window.BMap && window.BMap.LocalSearch) {
        const localSearch = new window.BMap.LocalSearch(mapInstance, {
          onSearchComplete: (results) => {
            if (results && results.getNumPois() > 0) {
              const firstResult = results.getPoi(0);
              this.mapCenter = firstResult.point;
              this.markerPosition = firstResult.point;
            } else {
              this.$message.error('未找到相关地点');
            }
          },
        });

        localSearch.search(this.searchQuery);
      } else {
        this.$message.error('百度地图 API 加载失败');
      }
    },

    // 定位当前位置
    locateCurrentPosition() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            this.mapCenter = { lng: longitude, lat: latitude };
            this.markerPosition = { lng: longitude, lat: latitude };
          },
          (error) => {
            this.$message.error('获取当前位置失败，请检查浏览器权限或手动输入位置');
            console.error('定位失败:', error);
          }
        );
      } else {
        this.$message.error('您的浏览器不支持定位功能');
      }
    },

    // 清除标记
    clearMarker() {
      this.markerPosition = null;
    },

    // 标记点拖动结束事件
    handleMarkerDragEnd(event) {
      this.previousMarkerPosition = this.markerPosition; // 保存旧位置
      this.markerPosition = {
        lng: event.point.lng,
        lat: event.point.lat,
      };
    },

    // 规划路线
    planRoute() {
      if (!this.routeStart || !this.routeEnd) {
        this.$message.warning('请输入起点和终点');
        return;
      }

      const geocoder = new window.BMap.Geocoder();

      // 解析起点，限制城市为武汉
      geocoder.getPoint(this.routeStart, (startPoint) => {
        if (!startPoint) {
          this.$message.error('无法解析起点');
          return;
        }

        // 解析终点，限制城市为武汉
        geocoder.getPoint(this.routeEnd, (endPoint) => {
          if (!endPoint) {
            this.$message.error('无法解析终点');
            return;
          }

          // 设置起点和终点的经纬度
          this.routeStartPoint = startPoint;
          this.routeEndPoint = endPoint;
          this.showRoute = true; // 显示路线

          // 将地图中心点设置为起点
          this.mapCenter = startPoint;
        }, '武汉市'); // 限制城市为武汉
      }, '武汉市'); // 限制城市为武汉
    },

    // 从当前位置导航
    startNavigationFromCurrentLocation() {
      if (!this.routeEnd) {
        this.$message.warning('请输入终点');
        return;
      }

      // 获取当前位置
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            this.routeStartPoint = { lng: longitude, lat: latitude }; // 设置起点为当前位置

            // 解析终点，限制城市为武汉
            const geocoder = new window.BMap.Geocoder();
            geocoder.getPoint(this.routeEnd, (endPoint) => {
              if (!endPoint) {
                this.$message.error('无法解析终点');
                return;
              }

              // 设置终点
              this.routeEndPoint = endPoint;
              this.showRoute = true; // 显示路线

              // 开始监听位置变化
              this.startWatchingPosition();
            }, '武汉市'); // 限制城市为武汉
          },
          (error) => {
            this.$message.error('获取当前位置失败，请检查浏览器权限或手动输入位置');
            console.error('定位失败:', error);
          }
        );
      } else {
        this.$message.error('您的浏览器不支持定位功能');
      }
    },

    // 开始监听位置变化
    startWatchingPosition() {
      if (navigator.geolocation) {
        this.watchPositionId = navigator.geolocation.watchPosition(
          (position) => {
            const { latitude, longitude } = position.coords;
            this.routeStartPoint = { lng: longitude, lat: latitude }; // 更新起点为当前位置
            this.mapCenter = { lng: longitude, lat: latitude }; // 更新地图中心点
          },
          (error) => {
            this.$message.error('获取实时位置失败');
            console.error('实时定位失败:', error);
          },
          { enableHighAccuracy: true, maximumAge: 10000, timeout: 5000 } // 定位选项
        );
      } else {
        this.$message.error('您的浏览器不支持定位功能');
      }
    },

    // 停止监听位置变化
    stopWatchingPosition() {
      if (this.watchPositionId && navigator.geolocation) {
        navigator.geolocation.clearWatch(this.watchPositionId);
        this.watchPositionId = null;
      }
    },

    // 路线规划完成事件
    onRouteComplete(results) {
      if (results) {
        console.log('路线规划完成', results);
        this.routeInfo = this.parseRouteInfo(results); // 解析并显示路线信息
      } else {
        this.$message.error('路线规划失败');
      }
    },

    // 解析路线信息
    parseRouteInfo(results) {
      const info = {
        time: '',
        distance: '',
        steps: [],
      };

      if (this.routeType === 'driving' || this.routeType === 'walking') {
        const plan = results.getPlan(0);
        info.time = plan.getDuration(true); // 获取时间
        info.distance = plan.getDistance(true); // 获取距离
      } else if (this.routeType === 'transit') {
        const plan = results.getPlan(0);
        info.time = plan.getDuration(true); // 获取时间
        info.distance = plan.getDistance(true); // 获取距离

        // 提取公交地铁的乘车路线信息
        plan.getRoutes().forEach((route) => {
          route.getSteps().forEach((step) => {
            const stepInfo = {
              description: step.getDescription(), // 步骤描述
              lines: [], // 具体的线路信息
            };

            // 提取具体的线路信息（如几号线）
            if (step.getLines) {
              step.getLines().forEach((line) => {
                stepInfo.lines.push(line.title); // 添加线路信息
              });
            }

            info.steps.push(stepInfo);
          });
        });
      }

      return info;
    },
  },
  beforeDestroy() {
    // 组件销毁时停止监听位置变化
    this.stopWatchingPosition();
  },
};
</script>

<style scoped>
.map {
  width: 100%;
  height: 100%;
  border-radius: 8px;
}
</style>