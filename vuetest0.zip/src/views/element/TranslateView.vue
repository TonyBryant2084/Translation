<template>
  <div id="app">
    <!-- 外部容器，防止水平滚动 -->
    <el-container style="height: 60vh; display: flex; margin: 0; overflow-x: hidden;">
      <!-- 左侧导航栏 -->
      <el-aside width="200px" style="background-color: #f4f6f9; border-right: 1px solid #ddd; padding: 20px; box-shadow: 2px 0px 5px rgba(0,0,0,0.1);">
        <span style="font-size: 24px; font-weight: bold; display: block; text-align: center; color: #409EFF;">旅译通</span>
        <el-menu :default-openeds="['1', '3']" active-text-color="#409EFF" style="overflow: hidden;">
          <el-submenu index="1">
            <template #title>功能菜单</template>
            <el-menu-item-group>
              <el-menu-item index="1-1">
                <router-link to="/translate">即时翻译</router-link>
              </el-menu-item>
              <el-menu-item index="1-2">
                <router-link to="/map">查看地图</router-link>
              </el-menu-item>
            </el-menu-item-group>
          </el-submenu>
        </el-menu>
      </el-aside>

      <!-- 主内容区域 -->
      <el-container style="flex-grow: 1; display: flex; flex-direction: column; padding: 20px; overflow-x: hidden;">
        <el-header style="text-align: center; font-size: 20px; line-height: 40px; height: 40px; background-color: #409EFF; color: #fff; border-radius: 10px;">
          即时翻译
        </el-header>

        <el-main style="flex-grow: 1; padding: 20px; overflow-y: auto; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 10px;">
          <p style="font-size: 18px; color: #333;">{{ translationResult }}</p>
        </el-main>
      </el-container>
    </el-container>

    <!-- 输入框区域 -->
    <div style="padding: 20px; width: 100%; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box;">
      <!-- 源语言和目标语言选择框并排显示 -->
      <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px; width: 100%; box-sizing: border-box;">
        <!-- 源语言选择框 -->
        <div style="display: flex; align-items: center; flex-grow: 1; margin-right: 10px;">
          <label style="font-size: 16px; color: #333; margin-right: 10px;">源语言：</label>
          <el-select 
            v-model="sourceLanguage" 
            style="width: 50%; font-size: 14px;" 
            placeholder="选择源语言">
            <el-option label="自动检测" value="auto"></el-option>
            <el-option label="中文" value="zh"></el-option>
            <el-option label="日语" value="ja"></el-option>
          </el-select>
        </div>

        <!-- 目标语言选择框 -->
        <div style="display: flex; align-items: center; flex-grow: 1;">
          <label style="font-size: 16px; color: #333; margin-right: 16px;">目标语言：</label>
          <el-select 
            v-model="targetLanguage" 
            style="width: 50%; font-size: 14px;" 
            placeholder="选择目标语言">
            <el-option label="中文" value="zh"></el-option>
            <el-option label="日语" value="ja"></el-option>
          </el-select>
        </div>
      </div>

      <el-input
        type="textarea"
        :rows="4"
        placeholder="请输入需要翻译的内容"
        v-model="textarea"
        style="margin-bottom: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); width: 100%; box-sizing: border-box;"
      ></el-input>

      <!-- 按钮并排显示 -->
      <div style="display: flex; gap: 10px; width: 100%; box-sizing: border-box;">
        <!-- 提交翻译按钮 -->
        <el-button 
          type="primary" 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="submitTranslation">
          提交翻译
        </el-button>

        <!-- 语音输入按钮 -->
        <el-button 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="startSpeechRecognition">
          语音输入
        </el-button>

        <!-- 图片翻译按钮 -->
        <el-button 
          type="primary" 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="openImageTranslation">
          图片翻译
        </el-button>
      </div>
    </div>

    <!-- 图片翻译弹窗 -->
    <el-dialog 
      title="图片翻译" 
      v-model="showImageDialog" 
      width="40%"
      @close="resetImage">
      <div style="text-align: center;">
        <!-- 上传图片区域 -->
        <div class="image-uploader">
          <input 
            type="file" 
            ref="fileInput"
            accept="image/*" 
            @change="handleFileUpload" 
            style="display: none;">
          <el-button 
            type="primary" 
            @click="$refs.fileInput.click()"
            style="margin-bottom: 20px;">
            <i class="el-icon-upload"></i> 上传图片
          </el-button>

          <div class="or-divider">或</div>

          <!-- 拍照按钮 -->
          <el-button 
            type="success" 
            @click="startCamera"
            :disabled="!cameraSupported">
            <i class="el-icon-camera"></i> 实时拍照
          </el-button>
        </div>

        <!-- 预览区域 -->
        <div v-if="previewImage" class="preview-area">
          <img :src="previewImage" alt="待翻译图片" class="preview-image">
          <div class="action-buttons">
            <el-button 
              type="danger" 
              @click="resetImage"
              icon="el-icon-delete">
              重新选择
            </el-button>
            <el-button 
              type="primary" 
              @click="translateImage"
              icon="el-icon-edit">
              开始翻译
            </el-button>
          </div>
        </div>

        <!-- 摄像头预览 -->
        <div v-if="showCameraPreview" class="camera-preview">
          <video ref="videoElement" autoplay></video>
          <el-button 
            type="primary" 
            @click="capturePhoto"
            class="capture-button">
            <i class="el-icon-camera-solid"></i> 拍摄照片
          </el-button>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script>
import axios from 'axios';
import md5 from 'js-md5';

export default {
  data() {
    return {
      textarea: '',
      recognition: null, 
      isListening: false, 
      sourceLanguage: 'auto', // 默认源语言为自动检测
      targetLanguage: 'ja', // 默认目标语言为日语
      translationResult: '翻译结果将显示在这里...',
      appId: '20250227002286666', 
      secretKey: 'RUtkbgtop5XgEQUxIiGB', 
      showImageDialog: false, // 图片翻译弹窗是否显示
      previewImage: null, // 预览图片的URL
      imageFile: null, // 上传的图片文件
      cameraSupported: true, // 是否支持摄像头
      showCameraPreview: false, // 是否显示摄像头预览
      mediaStream: null // 摄像头媒体流
    };
  },
  mounted() {
    if ('webkitSpeechRecognition' in window) {
      this.recognition = new window.webkitSpeechRecognition();
      this.recognition.lang = 'zh-CN'; 
      this.recognition.interimResults = false; 
      this.recognition.onresult = this.handleSpeechResult;
      this.recognition.onerror = this.handleSpeechError;
    } else {
      console.log('您的浏览器不支持语音识别功能');
    }
  },
  methods: {
    // 提交文本翻译
    submitTranslation() {
      if (this.textarea) {
        const salt = Math.random().toString(36).substr(2, 16);
        const sign = this.appId + this.textarea + salt + this.secretKey;
        const signMd5 = md5(sign);

        axios.get('/api/api/trans/vip/translate', {
          params: {
            q: this.textarea,
            from: this.sourceLanguage, // 使用用户选择的源语言
            to: this.targetLanguage,
            appid: this.appId,
            salt: salt,
            sign: signMd5
          }
        })
        .then(response => {
          if (response.data.trans_result) {
            this.translationResult = response.data.trans_result[0].dst;
          } else {
            const errorMsg = response.data.error_msg || '未知错误';
            console.error('翻译失败原因:', errorMsg);
            this.translationResult = `翻译失败: ${errorMsg}`;
          }
        })
        .catch(error => {
          console.error('翻译请求出错:', error);
          this.translationResult = '翻译请求出错，请检查网络或稍后重试';
        });
      }
    },

    // 语音输入
    startSpeechRecognition() {
      if (!this.isListening) {
        this.isListening = true;
        this.recognition.start();
      } else {
        this.isListening = false;
        this.recognition.abort();
      }
    },

    // 处理语音识别结果
    handleSpeechResult(event) {
      const transcript = event.results[0][0].transcript;
      this.textarea += transcript;
      this.isListening = false;
    },

    // 处理语音识别错误
    handleSpeechError(event) {
      console.log('语音识别错误:', event.error);
      this.isListening = false;
    },

    // 打开图片翻译对话框
    openImageTranslation() {
      this.showImageDialog = true;
      this.resetImage();
    },

    // 处理文件上传
    handleFileUpload(event) {
      const file = event.target.files[0];
      if (file) {
        this.imageFile = file;
        this.previewImage = URL.createObjectURL(file);
        this.showCameraPreview = false;
      }
    },

    // 启动摄像头
    async startCamera() {
      try {
        this.mediaStream = await navigator.mediaDevices.getUserMedia({ video: true });
        this.showCameraPreview = true;
        this.$nextTick(() => {
          const video = this.$refs.videoElement;
          video.srcObject = this.mediaStream;
        });
      } catch (error) {
        console.error('摄像头访问失败:', error);
        this.$message.error('无法访问摄像头，请检查权限设置');
        this.cameraSupported = false;
      }
    },

    // 拍摄照片
    capturePhoto() {
      const video = this.$refs.videoElement;
      const canvas = document.createElement('canvas');
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      canvas.getContext('2d').drawImage(video, 0, 0);
      
      canvas.toBlob(blob => {
        this.imageFile = new File([blob], 'capture.jpg', { type: 'image/jpeg' });
        this.previewImage = URL.createObjectURL(blob);
        this.showCameraPreview = false;
        this.stopCamera();
      }, 'image/jpeg');
    },

    // 停止摄像头
    stopCamera() {
      if (this.mediaStream) {
        this.mediaStream.getTracks().forEach(track => track.stop());
        this.mediaStream = null;
      }
    },

    // 重置图片状态
    resetImage() {
      this.previewImage = null;
      this.imageFile = null;
      this.stopCamera();
      this.showCameraPreview = false;
      if (this.$refs.fileInput) {
        this.$refs.fileInput.value = '';
      }
    },

    // 执行图片翻译
    async translateImage() {
      if (!this.imageFile) {
        this.$message.warning('请先选择或拍摄图片');
        return;
      }

      try {
        // Step 1: 调用OCR API识别文字
        const ocrResult = await this.recognizeText(this.imageFile);
        
        // Step 2: 调用翻译API
        const translation = await this.translateText(ocrResult);
        
        // Step 3: 显示结果
        this.translationResult = translation;
        this.showImageDialog = false;
      } catch (error) {
        console.error('翻译失败:', error);
        this.$message.error('翻译失败：' + error.message);
      }
    },

    // OCR文字识别（需要实现）
    async recognizeText(imageFile) {
      // 这里替换为实际的OCR API调用
      const formData = new FormData();
      formData.append('image', imageFile);
      
      const response = await axios.post('YOUR_OCR_API_ENDPOINT', formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      });
      
      if (response.data.error) {
        throw new Error(response.data.error);
      }
      return response.data.text; // 假设返回包含识别文本的字段
    },

    // 文本翻译（已有功能复用）
    translateText(text) {
      return new Promise((resolve, reject) => {
        const salt = Math.random().toString(36).substr(2, 16);
        const sign = md5(this.appId + text + salt + this.secretKey);
        
        axios.get('/api/api/trans/vip/translate', {
          params: {
            q: text,
            from: this.sourceLanguage,
            to: this.targetLanguage,
            appid: this.appId,
            salt: salt,
            sign: sign
          }
        })
        .then(response => {
          if (response.data.trans_result) {
            resolve(response.data.trans_result[0].dst);
          } else {
            reject(new Error(response.data.error_msg || '翻译失败'));
          }
        })
        .catch(reject);
      });
    }
  }
};
</script>

<style scoped>
/* 新增样式 */
.image-uploader {
  padding: 20px;
  border: 2px dashed #ddd;
  border-radius: 8px;
  margin-bottom: 20px;
}

.or-divider {
  margin: 15px 0;
  color: #999;
  font-size: 14px;
}

.preview-area {
  margin-top: 20px;
}

.preview-image {
  max-width: 100%;
  max-height: 300px;
  border-radius: 8px;
  box-shadow: 0 2px 12px rgba(0,0,0,0.1);
}

.action-buttons {
  margin-top: 20px;
  display: flex;
  justify-content: center;
  gap: 15px;
}

.camera-preview {
  position: relative;
  margin: 20px auto;
  max-width: 100%;
}

.camera-preview video {
  width: 100%;
  border-radius: 8px;
}

.capture-button {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  box-shadow: 0 2px 8px rgba(0,0,0,0.2);
}
</style>