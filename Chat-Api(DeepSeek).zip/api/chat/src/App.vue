<template>
  <div id="app">
    <div class="chat-container">
      <!-- 插入日本风景图片 -->
      <div class="background-image">
        <img src="https://example.com/japan-landscape.jpg" alt="Japanese Landscape" />
      </div>

      <div class="messages" ref="messagesContainer">
        <div v-for="(message, index) in messages" :key="index" :class="['message', message.role]">
          <div class="message-content" v-html="formatMessageContent(message.content)"></div>
        </div>
      </div>

      <div class="input-container">
        <input
          v-model="userMessage"
          type="text"
          placeholder="请输入您的消息"
          @keyup.enter="sendMessage"
        />
        <button @click="sendMessage">发送</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      userMessage: '',
      messages: [],
    };
  },
  methods: {
    async sendMessage() {
      if (this.userMessage.trim()) {
        // 显示用户的消息
        this.messages.push({ role: 'user', content: this.userMessage });

        // 清空输入框
        const userMessage = this.userMessage;
        this.userMessage = '';

        // 滚动到底部
        this.$nextTick(() => {
          this.$refs.messagesContainer.scrollTop = this.$refs.messagesContainer.scrollHeight;
        });

        try {
          // 调用后端 API
          const response = await axios.post('http://localhost:8080/api/chat', {
            model: 'deepseek-r1:1.5b',
            messages: [{ role: 'user', content: userMessage }],
            stream: false,
          });

          // 显示 DeepSeek 的回复
          if (response.data && response.data.message) {
            const aiMessage = this.formatMessageContent(response.data.message.content);
            this.messages.push({ role: 'assistant', content: aiMessage });

            // 滚动到底部
            this.$nextTick(() => {
              this.$refs.messagesContainer.scrollTop = this.$refs.messagesContainer.scrollHeight;
            });
          }
        } catch (error) {
          console.error('发生错误:', error);
          this.messages.push({ role: 'assistant', content: '发生错误，请稍后再试！' });
        }
      }
    },
    // 格式化消息内容
    formatMessageContent(content) {
      // 移除 <think> 标签
      content = content.replace(/<think>.*?<\/think>/g, '');

      // 将 Markdown 格式转换为 HTML
      content = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // **加粗**
        .replace(/\*(.*?)\*/g, '<em>$1</em>') // *斜体*
        .replace(/^- (.*?)(\n|$)/gm, '<li>$1</li>') // - 列表项
        .replace(/(<li>.*<\/li>)/g, '<ul>$1</ul>'); // 将列表项包裹在 <ul> 中

      return content;
    },
  },
};
</script>

<style scoped>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  padding: 20px;
  background-color: #f0f4f8;
  min-height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

.chat-container {
  width: 100%;
  max-width: 600px;
  height: 80vh;
  background-color: #ffffff;
  border-radius: 20px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  position: relative; /* 使背景图片位于容器之下 */
}

.background-image {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: -1; /* 确保背景图片在内容后面 */
}

.background-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  opacity: 0.5; /* 调整图片的透明度 */
}

.messages {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: #f9f9f9;
  border-bottom: 1px solid #eee;
}

.message {
  margin-bottom: 15px;
  display: flex;
}

.message.user {
  justify-content: flex-end;
}

.message.assistant {
  justify-content: flex-start;
}

.message-content {
  max-width: 70%;
  padding: 15px 20px;
  border-radius: 15px;
  position: relative;
  background: linear-gradient(135deg, #f1f7fb, #e3f2fd);
  color: #333; /* 文字颜色保持不透明 */
  word-wrap: break-word;
  white-space: pre-wrap;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  font-size: 16px;
}

.message.user .message-content {
  background-color: #007bff;
  color: white;
  border-bottom-right-radius: 0;
  box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3);
}

.message.assistant .message-content {
  background-color: #e1f7e0;
  color: #333;
  border-bottom-left-radius: 0;
}

.input-container {
  display: flex;
  padding: 10px;
  background-color: #ffffff;
  border-top: 1px solid #eee;
}

input {
  flex: 1;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-right: 10px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

input:focus {
  border-color: #007bff;
}

button {
  padding: 12px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease, transform 0.3s ease;
}

button:hover {
  background-color: #0056b3;
  transform: translateY(-2px);
}

button:active {
  background-color: #003f7f;
  transform: translateY(0);
}

</style>
