module.exports = {
  devServer: {
    proxy: {
      '/api': {
        target: 'http://localhost:8080',  // 后端服务地址
        changeOrigin: true,  // 支持跨域
        pathRewrite: {
          '^/api': ''  // 将 /api 重写为空，即请求 http://localhost:8080/api/chat 被代理为 http://localhost:8080/chat
        }
      }
    }
  }
};
