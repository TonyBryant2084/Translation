const express = require('express');
const axios = require('axios');
const bodyParser = require('body-parser');
const cors = require('cors');

// 创建一个 Express 应用
const app = express();
const port = 8080;

// 使用中间件
app.use(cors());
app.use(bodyParser.json());

// 处理聊天请求
app.post('/api/chat', async (req, res) => {
    const { model, messages, stream } = req.body;

    try {
        // 调用 DeepSeek API
        const response = await axios.post('http://localhost:11434/api/chat', {
            model,
            messages,
            stream,
        });

        // 返回 DeepSeek 的回应
        res.json(response.data);
    } catch (error) {
        console.error('调用 DeepSeek 时出错:', error);
        // 如果调用出错，返回详细错误信息
        if (error.response) {
            console.error('DeepSeek 错误:', error.response.data);
            res.status(500).json({ error: error.response.data });
        } else {
            console.error('网络请求错误:', error.message);
            res.status(500).json({ error: '无法连接到 DeepSeek 服务' });
        }
    }
});

// 启动服务
app.listen(port, () => {
    console.log(`后端服务已启动，监听端口 ${port}`);
});
