import Vue from 'vue'
import App from './App.vue'
import router from './router'
import store from './store'
import ElementUI from 'element-ui';
import 'element-ui/lib/theme-chalk/index.css';
import axios from './http'

import BaiduMap from 'vue-baidu-map'; // 导入百度地图插件

// 使用百度地图插件，并传入百度地图的 API 密钥
Vue.use(BaiduMap, {
  ak: 'oEW7cnhVgfB5PPMgmOmdnpKvy1z9KfE4', // 替换为你自己的百度地图 API 密钥
});

Vue.use(ElementUI);

Vue.prototype.$axios = axios

Vue.config.productionTip = false

new Vue({
  router,
  store,
  render: h => h(App)
}).$mount('#app')
