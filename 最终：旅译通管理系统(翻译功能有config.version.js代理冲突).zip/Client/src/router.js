import Vue from 'vue'
import Router from 'vue-router'
import Record from './views/Record/Record.vue'
import Theme from './views/front/ThemeView.vue'
import Register from './views/Register'
import Nofind from './views/404'
import Login from './views/Login'
import Home from './views/Home'
import InfoShow from './views/InfoShow'
import FoundList from './views/front/FoundList'

Vue.use(Router)

const router = new Router({
  mode: 'history',
  base: process.env.BASE_URL,
  routes: [
    {
      path: '*',
      name: '/404',
      component: Nofind
    },
    // {
    //   path: '/',
    //   redirect: '/index'
    // },
    {
      path: '/',
      name: 'theme',
      component: Theme
    },
    {
      path: '/itinerary/:id',
      name: 'ItineraryDetail',
      component: () => import('./views/front/ItineraryDetail.vue'),
      props: true, // 将路由参数作为 props 传递给组件
    },
    {
      path: '/recommend',
      name: 'recommend',
      component: () => import('./views/front/RecommendView.vue'),
      // meta: { requiresAuth: true }, // 需要登录才能访问
    },
    {
      path: '/translate',
      name: 'translate',
      component: () => import('./views/front/TranslateView.vue'),
      // meta: { requiresAuth: true }, // 需要登录才能访问
    },
    {
      path: '/map', // 路由路径
      name: 'map', // 路由名称
      component: () => import('./views/front/MapView.vue'), // 懒加载组件
      // meta: { requiresAuth: true }, // 需要登录才能访问
    },
    {
      path: '/NeDetail/:id',
      name: 'NewsDetail',
      component: () => import('./views/front/NeDetail.vue'),
      props: true, // 将路由参数作为 props 传递给组件
    },
    // {
    //   path: '/record',
    //   name: 'record',
    //   component: () => import('./views/front/FoundList.vue'),
    //   // meta: { requiresAuth: true }, // 需要登录才能访问
    // },
    {
      path: '/register',
      name: 'register',
      component: Register
    },
    {
      path: '/login',
      name: 'login',
      component: Login
    },
    {
      path: '/foundlist',
      component: FoundList,
    },

    // {
    //   path: '/about',
    //   name: 'about',
    //   // route level code-splitting
    //   // this generates a separate chunk (about.[hash].js) for this route
    //   // which is lazy-loaded when the route is visited.
    //   component: () => import(/* webpackChunkName: "about" */ './views/About.vue')
    // }
  ]
})

// 添加路由守卫
router.beforeEach((to, from, next) => {
  const isLogin = localStorage.eleToken ? true : false;
  if (to.path == "/login" || to.path == "/register") {
    next();
  } else {
    isLogin ? next() : next("/login");
  }
})

export default router;