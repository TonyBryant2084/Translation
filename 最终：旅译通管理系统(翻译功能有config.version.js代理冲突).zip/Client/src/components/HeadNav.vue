<template>
    <!-- 顶部导航栏 -->
    <el-menu :default-active="activeIndex" class="head-nav" mode="horizontal" background-color="#2c6eb3"
        text-color="#fff" active-text-color="#ff8c1a">
        <el-menu-item index="1">
            <span class="menu-item">
                <span class="cn-text">旅译通 / 旅译通</span>
            </span>
        </el-menu-item>
        <el-menu-item index="2">
            <span class="menu-item">
                <span class="cn-text">
                    <router-link to="/" style="text-decoration: none">
                        首页 / ホーム</router-link>
                </span>
            </span>
        </el-menu-item>
        <el-menu-item index="3">
            <span class="menu-item">
                <span class="cn-text">
                    <router-link to="/recommend" style="text-decoration: none">
                        推荐景点 / おすすめスポットです</router-link>
                </span>
            </span>
        </el-menu-item>
        <el-menu-item index="4">
            <span class="menu-item">
                <router-link to="/translate" style="text-decoration: none">
                    翻译/翻訳
                </router-link>
            </span>
        </el-menu-item>
        <el-menu-item index="5">
            <span class="menu-item">
                <router-link to="/map" style="text-decoration: none">
                    地图/地図
                </router-link>
            </span>
        </el-menu-item>

        <el-menu-item index="6">
            <span class="menu-item">
                <router-link to="/foundlist" style="text-decoration: none">
                    收入或支出/収入または支出
                </router-link>
            </span>
        </el-menu-item>


        <el-col :span='6' class="user">
            <div class="userinfo">
                <img src="" class='avatar' alt="">
                <div class='welcome'>
                    <p class='name comename'>欢迎</p>
                    <p class='name avatarname'>{{ user.name }}</p>
                </div>
                <span class='username'>
                    <el-dropdown trigger="click" @command='setDialogInfo'>
                        <span class="el-dropdown-link">
                            <i class="el-icon-caret-bottom el-icon--right"></i>
                        </span>
                        <el-dropdown-menu slot="dropdown">
                            <!-- <el-dropdown-item command='info'>个人信息</el-dropdown-item> -->
                            <el-dropdown-item command='logout'>退出</el-dropdown-item>
                        </el-dropdown-menu>
                    </el-dropdown>
                </span>
            </div>
        </el-col>


    </el-menu>
</template>
<script>
export default {
    name: "head-nav",
    computed: {
        user() {
            return this.$store.getters.user;
        }
    },
    methods: {
        setDialogInfo(cmditem) {
            if (!cmditem) {
                console.log("test");
                this.$message("菜单选项缺少command属性");
                return;
            }
            switch (cmditem) {
                case "info":
                    this.showInfoList();
                    break;
                case "logout":
                    this.logout();
                    break;
            }
        },
        showInfoList() {
            // 个人信息
            this.$router.push("/infoshow");
        },
        logout() {
            // 清除token
            localStorage.removeItem("eleToken");
            this.$store.dispatch("clearCurrentState");

            // 页面跳转
            this.$router.push("/login");
        }
    }
};
</script>

<style scoped>
.logo-container {
    line-height: 60px;
    min-width: 400px;
}

.logo {
    height: 50px;
    width: 50px;
    margin-right: 5px;
    vertical-align: middle;
    display: inline-block;
}

.title {
    vertical-align: middle;
    font-size: 22px;
    font-family: "Microsoft YaHei";
    letter-spacing: 3px;
}

.user {
    line-height: 60px;
    text-align: right;
    float: right;
    padding-right: 10px;
}

.avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    vertical-align: middle;
    display: inline-block;
}

.welcome {
    display: inline-block;
    width: auto;
    vertical-align: middle;
    padding: 0 5px;
}

.name {
    line-height: 20px;
    text-align: center;
    font-size: 14px;
}

.comename {
    font-size: 12px;
}

.avatarname {
    color: #409eff;
    font-weight: bolder;
}

.username {
    cursor: pointer;
    margin-right: 5px;
}

.el-dropdown {
    color: #fff;
}
</style>
