<template>
  <div class="app-container">
       <!-- 顶部导航栏 -->
    <HeadNav></HeadNav>

    <!-- 轮播图 -->
    <el-carousel :interval="5000" type="card" height="400px">
      <el-carousel-item v-for="(img, index) in images" :key="index">
        <img :src="img" class="carousel-img" />
      </el-carousel-item>
    </el-carousel>

    <!-- 推荐内容 -->
    <div class="recommendation-section">
      <h2 class="section-title">推荐景点 / おすすめの観光地</h2>
      <el-row :gutter="20">
        <el-col
          :span="6"
          v-for="(item, index) in items"
          :key="index"
          @mouseenter="changeImage(index)"
          @mouseleave="resetImage(index)"
        >
          <el-card :body-style="{ padding: '0px' }" class="card">
            <img :src="item.currentImage" class="image" />
            <div class="content">
              <div class="title">
                <span>{{ item.title }} / {{ item.jpTitle }}</span>
              </div>
              <div class="description">
                <p>{{ item.description }} / {{ item.jpDescription }}</p>
              </div>
              <div class="action">
                <el-button type="primary" @click="viewDetails(item)">
                  查看详情 / 詳細を見る
                </el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
    <!-- 推荐新闻 -->
    <div class="recommendation-section">
      <h2 class="section-title">推荐新闻 / おすすめのニュース</h2>
      <el-row :gutter="20">
        <el-col
          :span="6"
          v-for="(newsItem, index) in news"
          :key="index"
          @mouseenter="changeNewsImage(index)"
          @mouseleave="resetNewsImage(index)"
        >
          <el-card :body-style="{ padding: '0px' }" class="card">
            <img :src="newsItem.currentImage" class="image" />
            <div class="content">
              <div class="title">
                <span>{{ newsItem.title }}</span>
              </div>
              <div class="description">
                <p>{{ newsItem.content }}</p>
              </div>
              <div class="action">
                <el-button type="primary" @click="viewDetailNews(newsItem)">
                  查看详情 / 詳細を見る
                </el-button>
              </div>
            </div>
          </el-card>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
import HeadNav from "../../components/HeadNav";
export default {
    components: {
    HeadNav,
  },
  data() {
    return {
      activeIndex: "2",
      images: [
        require("@/assets/bim1.jpg"),
        require("@/assets/bim2.jpg"),
        require("@/assets/bim3.jpg"),
      ],
      items: [
        {
          id: 1,
          title: "鸟羽",
          jpTitle: "鳥羽",
          image: require("@/assets/scene1.jpg"),
          hoverImage: require("@/assets/scene1-hover.jpg"),
          currentImage: require("@/assets/scene1.jpg"),
          description:
            "鸟羽是一个美丽的海滨城市，以其丰富的海洋资源和美丽的风景而著名。这里是一个放松和享受海洋的理想之地。",
          jpDescription:
            "鳥羽は美しい海辺の都市で、豊富な海洋資源と美しい景色で有名です。ここはリラックスして海を楽しむのに最適な場所です。",
        },
        {
          id: 2,
          title: "姬路",
          jpTitle: "姫路",
          image: require("@/assets/scene2.jpg"),
          hoverImage: require("@/assets/scene2-hover.jpg"),
          currentImage: require("@/assets/scene2.jpg"),
          description:
            "姬路以其雄伟的姬路城而著名，姬路城被联合国教科文组织列为世界遗产，是日本最具代表性的古代城堡之一。",
          jpDescription:
            "姫路はその壮大な姫路城で有名で、姫路城はユネスコの世界遺産に登録されており、日本で最も代表的な古代の城の1つです。",
        },
        {
          id: 3,
          title: "京都",
          jpTitle: "京都",
          image: require("@/assets/scene3.jpg"),
          hoverImage: require("@/assets/scene3-hover.jpg"),
          currentImage: require("@/assets/scene3.jpg"),
          description:
            "京都是日本的文化心脏，拥有众多的神社、寺庙和传统茶室。这里保存着丰富的历史遗产，是体验日本古老文化的好地方。",
          jpDescription:
            "京都は日本の文化の中心で、多くの神社、寺院、伝統的な茶室を有しています。存されており、日本の古代文化を体験するのに。",
        },
        {
          id: 4,
          title: "东京",
          jpTitle: "東京",
          image: require("@/assets/scene4.jpg"),
          hoverImage: require("@/assets/scene4-hover.jpg"),
          currentImage: require("@/assets/scene4.jpg"),
          description:
            "东京是日本的现代化大都市，融合了传统与未来的元素。从高耸的摩天大楼到古老的寺庙，是一个永不停息的城市。",
          jpDescription:
            "東京は日本の近代的な大都市で、伝統と未来の要素が融合しています。高層ビルから古い寺院まで、東京は止まることのない都市です。",
        },
      ],
      news: [
        {
          id: 5,
          title: "樱花季/桜の季節です",
          date: "2025-03-15",
          content:
            "日本各地的樱花季即将开始/日本各地で桜のシーズンが始まります",
          image: require("@/assets/new1.jpg"),
          hoverImage: require("@/assets/scene1-hover.jpg"),
          currentImage: require("@/assets/new1.jpg"),
        },
        {
          id: 6,
          title: "旅游政策/観光政策です",
          date: "2025-03-10",
          content:
            "日本政府宣布推出新的旅游政策/日本政府は新しい観光政策を発表しました",
          image: require("@/assets/scene2.jpg"),
          hoverImage: require("@/assets/scene2-hover.jpg"),
          currentImage: require("@/assets/new5.jpg"),
        },
        {
          id: 7,
          title: "奥运会遗产/オリンピック遺産です",
          date: "2025-03-05",
          content:
            "东京奥运会相关场馆和设施将被重新利用/東京オリンピックの施設と施設は再利用されます",
          image: require("@/assets/scene3.jpg"),
          hoverImage: require("@/assets/scene3-hover.jpg"),
          currentImage: require("@/assets/new4.jpg"),
        },
        {
          id: 8,
          title: "日本美食节/日本フスティバルです",
          date: "2025-03-01",
          content:
            "日本各地将举办美食节/日本各地でグルメ祭りが開催されます",
          image: require("@/assets/scene4.jpg"),
          hoverImage: require("@/assets/scene4-hover.jpg"),
          currentImage: require("@/assets/new8.jpg"),
        },
      ],
    };
  },
  methods: {
    changeImage(index) {
      this.items[index].currentImage = this.items[index].hoverImage;
    },
    resetImage(index) {
      this.items[index].currentImage = this.items[index].image;
    },
    viewDetails(item) {
      console.log("跳转到详情页，ID:", item.id);
      this.$router.push({ name: "ItineraryDetail", params: { id: item.id } });
    },
    viewDetailNews(newsItem) {
      console.log("跳转到新闻详情页，ID:", newsItem.id);
      this.$router.push({ name: "NewsDetail", params: { id: newsItem.id } });
    },
  },
};
</script>

<style scoped>
.app-container {
  text-align: center;
}

.nav-bar {
  font-size: 18px;
}

.carousel-img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.recommendation-section {
  padding: 20px;
  background-color: #f5f5f5;
}

.section-title {
  font-size: 24px;
  font-weight: bold;
  margin-bottom: 20px;
  color: #333;
}

.image {
  width: 100%;
  height: 200px; /* 固定图片的高度 */
  object-fit: cover;
  transition: transform 0.3s ease-in-out;
}

.el-card {
  border: none;
  box-shadow: 0px 4px 12px rgba(0, 0, 0, 0.1);
  position: relative;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%; /* 设置卡片高度为100% */
}

.el-row {
  margin-bottom: 20px;
}

.el-col {
  padding: 10px;
}

.el-col:hover {
  transform: scale(1.05);
}

.el-card:hover {
  box-shadow: 0px 6px 20px rgba(0, 0, 0, 0.2);
}

.card {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.content {
  padding: 14px;
  text-align: center;
  flex-grow: 1; /* 让内容部分适应剩余空间 */
}

.title {
  font-size: 18px;
  font-weight: bold;
  margin-bottom: 10px;
  color: #2c6eb3;
}

.description {
  font-size: 14px;
  color: #555;
  line-height: 1.5;
  margin-bottom: 15px;
}

.action {
  margin-top: 10px;
}

.el-button {
  width: 100%;
}
</style>
