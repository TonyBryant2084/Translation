<template>
  <div class="news-detail" :style="{ backgroundColor: '#f5f5f5', padding: '40px 300px', fontFamily: 'Roboto', }">
    <!-- 顶部图片 -->
    <div class="header-image">
      <img
        :src="newsItem.currentImage"
        alt="news-header"
        @mouseout="resetImage"
      />
    </div>

    <!-- 新闻标题与日期 -->
    <div class="title-section">
      <h1>{{ newsItem.title }}</h1>
      <p>{{ newsItem.date }}</p>
    </div>

    <!-- 新闻内容 -->
    <div class="content-section">
      <el-row :gutter="20">
        <el-col :span="24">
          <div class="news-content">
            <div v-html="newsItem.content"></div>
            <img :src="newsItem.hoverImage" alt="">
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  props: ["id"], // 接收路由参数
  data() {
    return {
      newsItem: {},
      news: [
        {
          id: 5,
          title: "日本樱花季即将到来",
          date: "2025-03-15",
          content:
            "&nbsp;&nbsp;日本樱花季即将到来，陆续绽放的樱花，已吸引不少民众前去观赏。星期三（3月12日）在东京上野公园，两名游客撑着伞，拍下雨中樱花的美景。日本樱花的最佳观赏期通常是3月下旬至4月初，温度越高，花就开得越早.<br><p></p>&nbsp;&nbsp;根据日本气象协会周三发布的樱花开花日期预报，爱媛县宇和岛市预计这个星期天（16日）就会开花，成为樱花最早绽放的地区。东京中心城区开花日期为22日、鹿儿岛市和高知市23日，福冈市24日，名古屋市25日，广岛市和大阪市27日。仙台市和札幌市的樱花则分别要到4月2日和25日才盛放。（法新社）",
          image: require("@/assets/new1.jpg"),
          hoverImage: require("@/assets/new2.png"),
          currentImage: require("@/assets/new1.jpg"),
        },
        {
          id: 6,
          title: "日本推出新旅游政策",
          date: "2025-03-10",
          content:
            "&nbsp;&nbsp;日本政府近日宣布推出全新的旅游政策，旨在吸引更多国际游客前来日本旅游。新的政策包括简化签证申请流程、增加旅游优惠和强化基础设施建设，以提供更好的服务和体验。<br><p></p>&nbsp;&nbsp;此外，日本还计划扩大与世界各国的旅游合作，特别是亚洲和欧洲市场，以进一步促进国际游客的流入。政府希望通过这一系列措施，刺激国内经济发展，并提升日本作为全球旅游目的地的吸引力。此举预计将为旅游行业带来显著增长。 <br><p></p>&nbsp;&nbsp;围绕中国公民旅游签证的签发条件，存在因快速放宽而可能导致日本国内治安恶化的担忧，因此日本也存在对放宽签证条件的持谨慎态度的意见。为此，日本政府未同意中方提出的双方旅游签证互免的建议，而是保留了一定的限制条件以加以约束。",
          image: require("@/assets/new3.jpg"),
          hoverImage: require("@/assets/scene2-hover.jpg"),
          currentImage: require("@/assets/new3.jpg"),
        },
        {
          id: 7,
          title: "东京奥运会遗产利用",
          date: "2025-03-05",
          content:
            "&nbsp;&nbsp;东京奥运会结束后，东京市政府决定对相关场馆和设施进行重新规划和利用，确保这些昂贵的基础设施能够长期服务于市民和游客。<br><p></p>&nbsp;&nbsp;奥运会期间使用的运动场馆将被改造为多功能场地，包括用于社区活动、体育赛事和文化活动等。同时，一些场馆也将用于举办大型音乐会、展览和其他国际赛事，吸引更多游客前来体验。其他设施如奥运村，也将转型为住宅区，为东京居民提供更多的居住空间。<br><p></p>&nbsp;&nbsp;这些变化不仅能提升城市的活力，还能带动当地经济的复苏，成为新的旅游和社交打卡地。。",
          image: require("@/assets/new4.jpg"),
          hoverImage: require("@/assets/scene3-hover.jpg"),
          currentImage: require("@/assets/new4.jpg"),
        },
        {
          id: 8,
          title: "日本美食节即将开幕",
          date: "2025-03-01",
          content:
            "&nbsp;&nbsp;日本各地将举办一系列美食节，展示丰富多样的传统和现代日本料理，吸引来自世界各地的美食爱好者。<br><p></p>&nbsp;&nbsp;这些美食节不仅有传统的寿司、天妇罗、拉面等经典日式菜肴，还将推出融合现代创新元素的料理，如创意寿司、分子料理等，满足不同口味需求。活动期间，游客可以亲自体验制作美食的过程，参与烹饪工作坊，还能品尝到最新鲜的地方特色食材。<br><p><p>&nbsp;&nbsp;除了美食，节庆活动还会结合日本的文化表演、音乐和艺术展览，为参与者提供一个全方位的感官盛宴。这些美食节成为了促进地方经济、文化交流以及提升旅游吸引力的重要平台。",
          image: require("@/assets/new8.jpg"),
          hoverImage: require("@/assets/scene4-hover.jpg"),
          currentImage: require("@/assets/new8.jpg"),
        },
      ],
    };
  },
  created() {
    this.loadNews(this.id);
  },
  watch: {
    "$route.params.id": {
      handler(newId) {
        this.loadNews(newId);
      },
      immediate: true,
    },
  },
  methods: {
    loadNews(id) {
      const news = this.news.find((item) => item.id === Number(id));
      if (news) {
        this.newsItem = news;
        console.log("加载的新闻数据:", this.newsItem);
      } else {
        this.newsItem = {};
        console.warn("未找到新闻数据:", id);
      }
    },
    hoverImage() {
      if (this.newsItem.hoverImage) {
        this.newsItem.currentImage = this.newsItem.hoverImage;
      }
    },
    resetImage() {
      if (this.newsItem.image) {
        this.newsItem.currentImage = this.newsItem.image;
      }
    },
  },
};
</script>

<style scoped>
.news-detail {
  padding: 40px 20px;
  font-family: "Roboto", sans-serif;
  background-color: #f5f5f5;
}

/* 顶部图片 */
.header-image img {
  width: 100%;
  height: auto;
  object-fit: contain;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.title-section {
  text-align: center;
  margin: 20px 0;
}

.title-section h1 {
  font-size: 36px;
  font-weight: bold;
  color: #003366;
}

.title-section p {
  font-size: 20px;
  color: #555;
}

.content-section {
  margin-top: 30px;
}
.news-content {
  width: 100%;  /* 确保新闻内容的宽度与父容器一致 */
  max-width: 100%;  /* 限制宽度 */
  margin: 0 auto; /* 居中 */
}
.news-content p {
  font-size: 18px;
  line-height: 1.8;
  color: #666;
}
.news-content img {
  width: 100%; /* 确保图片宽度和文本宽度一致 */
  height: auto;
  margin-top: 20px; /* 图片与文字之间留有间距 */
}
/* 响应式设计 */
@media (max-width: 768px) {
  .header-image img {
    height: 250px;
  }
}
</style>
