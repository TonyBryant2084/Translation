<template>
  <div
    class="itinerary-detail"
    :style="{ backgroundColor: detail.backgroundColor ,padding: '40px 300px'}"
  >
    <!-- 顶部图片 -->
    <div class="header-image">
      <img :src="detail.headerImage" alt="header" />
    </div>

    <!-- 行程标题 -->
    <div class="title-section">
      <h1>{{ detail.title }}</h1>
      <p>{{ detail.subtitle }}</p>
    </div>

    <!-- 行程详情 -->
    <div class="content-section">
      <el-row :gutter="20">
        <el-col :span="16">
          <!-- 行程介绍 -->
          <div class="itinerary-description">
            <h2>行程介绍</h2>
            <p>{{ detail.description }}</p>
          </div>
          <!-- 新增：行程图片 -->
          <div class="itinerary-image">
            <img :src="detail.image" alt="itinerary-image" />
          </div>
          <!-- 行程亮点 -->
          <div class="itinerary-highlights">
            <h2>行程亮点</h2>
            <ul>
              <li v-for="(highlight, index) in detail.highlights" :key="index">
                {{ highlight }}
              </li>
            </ul>
          </div>
        </el-col>
        <el-col :span="8">
          <div class="itinerary-info">
            <h2>行程信息</h2>
            <p><strong>天数：</strong>{{ detail.days }} 天</p>
            <p><strong>价格：</strong>{{ detail.price }}</p>
            <p><strong>出发地：</strong>{{ detail.departure }}</p>
            <el-button type="primary" @click="bookNow" class="book-button"
              >立即预订</el-button
            >
          </div>
        </el-col>
      </el-row>
    </div>
  </div>
</template>

<script>
export default {
  props: ["id"], // 接收路由参数
  data() {
    return {
      detail: {},
      itineraryData: [
        {
          id: 1,
          title: "鸟羽海滨之旅",
          subtitle: "探索美丽的海滨城市",
          headerImage: require("@/assets/scene1.jpg"),
          image: require("@/assets/scene1-hover.jpg"), // 新增 image 字段
          description:
            "鸟羽是一个风景如画的海滨城市，以其丰富的海洋资源和悠久的渔业文化而著称。这里拥有清澈的海水、迷人的沙滩和丰富的海洋生物资源，是日本著名的渔业基地之一。游客可以在鸟羽水族馆欣赏各种珍稀的海洋生物，体验与海豚互动的乐趣。此外，鸟羽也是日本著名的“海女文化”发源地，您可以亲眼目睹海女们潜水采集海产的壮观场景，感受这一独特的传统文化。",
          highlights: [
            "参观日本最大的鸟羽水族馆，欣赏超过850种海洋生物。",
            "体验千年传承的海女文化，观看海女潜水表演并尝试亲手制作海胆寿司。",
            "品尝鸟羽当地特色的伊势龙虾和新鲜的海鲜盛宴。",
            "乘坐观光游船，欣赏鸟羽湾壮丽的日落景色。",
          ],
          days: 3,
          price: "￥15,000 起",
          departure: "东京",
          backgroundColor: "#e0f7fa", // 浅蓝色
        },
        {
          id: 2,
          title: "姬路城文化之旅",
          subtitle: "探索世界遗产姬路城",
          headerImage: require("@/assets/scene2.jpg"),
          image: require("@/assets/scene2-hover.jpg"), // 新增 image 字段
          description:
            "姬路是日本历史文化的瑰宝，以其保存完好的古代城堡——姬路城而闻名于世。姬路城建于14世纪，被联合国教科文组织列为世界遗产，是日本保存最完整、最具代表性的木造城堡。城堡白墙在阳光的映照下宛如白鹤展翅，因此又被称为“白鹭城”。您可以穿着和服，漫步在城内的古道上，仿佛穿越回了日本战国时代。",
          highlights: [
            "参观保存完好的姬路城主城，探索日本战国时代的建筑工艺。",
            "体验和服租赁，在城内拍摄唯美的和风写真。",
            "参加传统的茶道体验，学习茶道礼仪并品尝抹茶和和果子。",
          ],
          days: 2,
          price: "￥10,000 起",
          departure: "大阪",
          backgroundColor: "#f5f5dc", // 米白色
        },
        {
          id: 3,
          title: "京都古都之旅",
          subtitle: "探索日本文化的心脏",
          headerImage: require("@/assets/scene3.jpg"),
          image: require("@/assets/scene3-hover.jpg"), // 新增 image 字段
          description:
            "京都是日本的文化中心，曾是日本的首都，拥有上千年历史。这里保存着众多的世界文化遗产，包括金阁寺、清水寺和伏见稻荷大社等。走在京都的街头，您可以看到穿着和服的行人、古老的茶屋和精致的日式庭院，感受到古老与现代的交融之美。此外，京都的怀石料理以精致和美味著称，是日本饮食文化的最高体现。",
          highlights: [
            "参观世界文化遗产金阁寺，欣赏镀金的建筑在湖水中的倒影。",
            "在祇园体验艺伎文化，观赏艺伎表演并与艺伎互动合影。",
            "体验和服租赁，漫步在古老的石板街道，感受平安时代的氛围。",
          ],
          days: 4,
          price: "￥20,000 起",
          departure: "京都",
          backgroundColor: "#e0f7fa", // 浅粉色
        },
        {
          id: 4,
          title: "东京现代都市之旅",
          subtitle: "探索传统与未来的完美融合",
          headerImage: require("@/assets/scene4.jpg"),
          image: require("@/assets/scene4-hover.jpg"), // 新增 image 字段
          description:
            "东京是日本的首都，是一个充满活力的现代化大都市。这里拥有世界上最繁忙的十字路口——涩谷十字路口，东京塔和晴空塔等地标性建筑，以及各类购物中心和餐饮店。从新宿的繁华夜景到浅草寺的传统庙宇，东京完美融合了现代与传统的元素。夜幕降临后，东京的霓虹灯和繁华的街道，展现出这座城市的独特魅力。",
          highlights: [
            "登上东京塔，俯瞰东京城市的繁华夜景。",
            "参观浅草寺，在雷门前祈福，体验日本传统的寺庙文化。",
            "秋叶原体验日本动漫和电器文化，购买限量版手办和电子产品。",
          ],
          days: 5,
          price: "￥25,000 起",
          departure: "东京",
          backgroundColor: "#f0f0f0", // 淡灰色
        },
      ],
    };
  },
  created() {
    this.loadDetail(this.id); // 初始化加载数据
  },
  watch: {
    "$route.params.id": {
      handler(newId) {
        this.loadDetail(newId); // 监听路由参数变化，重新加载数据
      },
      immediate: true,
    },
  },
  methods: {
    loadDetail(id) {
      const itinerary = this.itineraryData.find(
        (item) => item.id === Number(id)
      );
      if (itinerary) {
        this.detail = itinerary;
        console.log("加载的详情数据:", this.detail);
      } else {
        this.detail = {}; // 没有找到数据时，设置为空对象或其他默认值
        console.warn("未找到行程数据:", id);
      }
    },
    bookNow() {
      if (this.detail.title) {
        alert("立即预订：" + this.detail.title);
        // window.location.href = "https://www.tickets.gotokyo.org/cn"; // 跳转到预订页面
      } else {
        alert("无法预订，行程数据未加载");
      }
    },
  },
};
</script>

<style scoped>
.itinerary-detail {
  padding: 40px 20px;
  font-family: "Roboto", sans-serif;
  background-color: #f5f5f5;
}

.header-image img {
  width: 100%;
  height: 400px;
  object-fit: cover;
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.title-section {
  text-align: center;
  margin: 20px 0;
}

.title-section h1 {
  font-size: 36px;
  font-weight: bold;
  color: #003366;
}

.title-section p {
  font-size: 20px;
  color: #555;
}

.content-section {
  margin-top: 30px;
}

/* 新增：行程图片样式 */
.itinerary-image img {
  width: 100%;
  height: 300px;
  object-fit: cover;
  border-radius: 8px;
  margin-bottom: 20px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
}

.itinerary-description,
.itinerary-highlights,
.itinerary-info {
  margin-bottom: 25px;
}

.itinerary-description p {
  font-size: 18px;
  color: #666;
}

.itinerary-highlights h2,
.itinerary-description h2,
.itinerary-info h2 {
  font-size: 24px;
  color: #003366;
  margin-bottom: 10px;
  border-bottom: 2px solid #003366;
  padding-bottom: 5px;
}

.itinerary-highlights ul {
  list-style: none;
  padding: 0;
}

.itinerary-highlights li {
  font-size: 18px;
  color: #333;
  margin-bottom: 10px;
}

.itinerary-info {
  background-color: #fff;
  padding: 25px;
  border-radius: 10px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

.itinerary-info p {
  font-size: 18px;
  color: #333;
  margin-bottom: 15px;
}

.el-button.book-button {
  background-color: #0066cc;
  color: white;
  width: 100%;
  padding: 12px;
  border-radius: 6px;
  font-size: 18px;
  font-weight: bold;
  border: none;
  transition: background-color 0.3s;
}

.el-button.book-button:hover {
  background-color: #004d99;
}

@media (max-width: 768px) {
  .content-section {
    padding: 15px;
  }
  .header-image img {
    height: 250px;
  }
  .itinerary-image img {
    height: 200px;
  }
}
</style>