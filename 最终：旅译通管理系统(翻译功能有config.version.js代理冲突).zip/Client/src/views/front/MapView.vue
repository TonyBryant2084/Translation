<template>
  <div id="app">
    <!-- 顶部导航栏 -->
    <HeadNav></HeadNav>

    <!-- 主内容区域 -->
    <div class="main-content">
      <!-- 地图容器 -->
      <el-row :gutter="20">
        <!-- <el-card class="map-card"> -->
        <baidu-map
          class="map"
          :center="mapCenter"
          :zoom="zoom"
          ref="baiduMap"
          @ready="onMapLoaded"
        >
          <bm-view class="map"></bm-view>
          <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>
          <bm-map-type
            :map-types="['BMAP_NORMAL_MAP', 'BMAP_HYBRID_MAP']"
            anchor="BMAP_ANCHOR_TOP_LEFT"
          ></bm-map-type>
          <bm-marker
            :position="markerPosition"
            :dragging="true"
            @dragend="handleMarkerDragEnd"
          ></bm-marker>
          <bm-driving
            v-if="showRoute && routeType === 'driving'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            :policy="routePolicy"
            @searchcomplete="onRouteComplete"
          ></bm-driving>
          <bm-transit
            v-if="showRoute && routeType === 'transit'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            @searchcomplete="onRouteComplete"
          ></bm-transit>
          <bm-transit
            v-if="showRoute && routeType === 'transit'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            @searchcomplete="onRouteComplete"
          ></bm-transit>
          <bm-walking
            v-if="showRoute && routeType === 'walking'"
            :start="routeStartPoint"
            :end="routeEndPoint"
            :auto-viewport="true"
            @searchcomplete="onRouteComplete"
          ></bm-walking>
        </baidu-map>
        <!-- </el-card> -->
      </el-row>

      <!-- 输入框区域 -->
      <el-row :gutter="20">
        <el-card class="input-card">
          <div class="input-section">
            <!-- 搜索地点、起点、终点输入框并排 -->
            <el-row :gutter="10" align="middle" class="input-row">
              <!-- 搜索地点输入框 -->
              <el-col :span="6">
                <el-input
                  v-model="searchQuery"
                  placeholder="搜索地点"
                  class="styled-input"
                ></el-input>
              </el-col>
              <el-col :span="2">
                <el-button
                  type="primary"
                  class="action-btn"
                  @click="searchLocation"
                  >搜索</el-button
                >
              </el-col>

              <!-- 起点输入框 -->
              <el-col :span="4"   style="margin-left: 109px;">
                <el-input
                  v-model="routeStart"
                  placeholder="起点"
                  class="styled-input"
                ></el-input>
              </el-col>

              <!-- 终点输入框 -->
              <el-col :span="4">
                <el-input
                  v-model="routeEnd"
                  placeholder="终点"
                  class="styled-input"
                ></el-input>
              </el-col>

              <!-- 导航模式下拉框 -->
              <el-col :span="3">
                <el-select
                  v-model="routeType"
                  placeholder="导航模式"
                  class="styled-select"
                >
                  <el-option label="自驾" value="driving"></el-option>
                  <el-option label="公交地铁" value="transit"></el-option>
                  <el-option label="步行" value="walking"></el-option>
                </el-select>
              </el-col>

              <!-- 规划路线按钮 -->
              <el-col :span="3">
                <el-button type="primary" class="action-btn" @click="planRoute"
                  >规划路线</el-button
                >
              </el-col>
            </el-row>

            <!-- 其他操作按钮 -->
            <el-row class="action-row">
              <el-col :span="24">
                <el-button
                  type="primary"
                  class="large-btn"
                  @click="startNavigationFromCurrentLocation"
                  >从当前位置导航</el-button
                >
                <el-button
                  type="primary"
                  class="large-btn"
                  @click="locateCurrentPosition"
                  >定位到当前位置</el-button
                >
              </el-col>
            </el-row>
          </div>
        </el-card>
      </el-row>
    </div>
  </div>
</template>

<script>

import HeadNav from "../../components/HeadNav";

/* global BMap */
export default {
  name: "MapView",
    components: {
    HeadNav,
  },
  data() {
    return {
      activeIndex: "5", // 默认选中地图菜单项
      mapCenter: { lng: 114.305, lat: 30.592 }, // 默认地图中心点为武汉
      zoom: 15, // 缩放级别
      markerPosition: { lng: 114.305, lat: 30.592 }, // 标记点位置
      searchQuery: "", // 搜索框内容
      routeStart: "", // 路线起点（地址字符串）
      routeEnd: "", // 路线终点（地址字符串）
      routeStartPoint: null, // 路线起点（经纬度）

      routeEndPoint: null, // 路线终点（经纬度）
      showRoute: true, // 是否显示路线
      routeType: "driving", // 导航模式（driving: 自驾, transit: 公交地铁, walking: 步行）
      routePolicy: "BMAP_DRIVING_POLICY_LEAST_TIME", // 自驾路线规划策略
      mapLoaded: false, // 地图加载状态
      watchPositionId: null, // 实时位置监听的 ID
      routeInfo: null, // 导航路线信息
      showPOIDialog: false, // 是否显示 POI 详情弹窗
      selectedPOI: null, // 当前选中的 POI
    };
  },
  methods: {
    // 地图加载完成事件
    onMapLoaded() {
      this.mapLoaded = true;
      console.log("地图加载完毕，可以搜索");

      // 添加 POI 点击事件监听
      const mapInstance = this.$refs.baiduMap.map;
      mapInstance.addEventListener("click", this.handleMapClick);
    },

    // 处理地图点击事件
    handleMapClick(e) {
      const mapInstance = this.$refs.baiduMap.map;
      const point = e.point;

      console.log("地图点击事件触发，点击位置:", point);

      // 确保 mapInstance 存在
      if (!mapInstance) {
        console.error("百度地图实例未初始化");
        return;
      }

      // 初始化 POI 搜索
      const localSearch = new BMap.LocalSearch(mapInstance, {
        renderOptions: { map: mapInstance },
        pageCapacity: 5, // 限制返回的 POI 数量
        enableAutoViewport: false, // 自动调整视角
        onSearchComplete: (results) => {
          console.log("搜索完成，搜索结果:", results);

          if (
            results &&
            typeof results.getCurrentNumPois === "function" &&
            results.getCurrentNumPois() > 0
          ) {
            const poi = results.getPoi(0);
            if (poi) {
              this.selectedPOI = {
                name: poi.title,
                address: poi.address || "暂无地址信息",
                point: poi.point,
              };
              this.showPOIDialog = true;
              console.log("找到 POI:", this.selectedPOI);
            } else {
              console.warn("未找到有效 POI 数据");
            }
          } else {
            console.warn("未找到相关 POI");
          }
        },
        onSearchError: (error) => {
          console.error("搜索失败:", error);
        },
      });

      // 搜索点击位置附近的 POI
      console.log("开始搜索 POI");
      localSearch.searchNearby("景点", point, 100000); // 附近 500m 搜索“景点”
    },

    // 搜索地点
    searchLocation() {
      if (this.searchQuery.trim() === "") {
        this.$message.warning("请输入地点名称");
        return;
      }

      // 确保地图实例已经加载
      const mapInstance = this.$refs.baiduMap.map;
      if (!mapInstance) {
        this.$message.warning("地图尚未加载");
        return;
      }

      // 使用百度地图的 LocalSearch 进行地点搜索
      const localSearch = new BMap.LocalSearch(mapInstance, {
        onSearchComplete: (results) => {
          if (results && results.getNumPois() > 0) {
            const firstResult = results.getPoi(0);
            this.mapCenter = firstResult.point; // 更新地图中心点
            this.markerPosition = firstResult.point; // 更新标记点位置
          } else {
            this.$message.error("未找到相关地点");
          }
        },
      });

      localSearch.search(this.searchQuery);
    },

    // 规划路线
    planRoute() {
      if (!this.routeStart || !this.routeEnd) {
        this.$message.warning("请输入起点和终点");
        return;
      }

      const geocoder = new BMap.Geocoder();

      // 获取起点的经纬度
      geocoder.getPoint(this.routeStart, (startPoint) => {
        if (!startPoint) {
          this.$message.warning("起点地址无效");
          return;
        }
        this.routeStartPoint = startPoint;

        // 获取终点的经纬度
        geocoder.getPoint(this.routeEnd, (endPoint) => {
          if (!endPoint) {
            this.$message.warning("终点地址无效");
            return;
          }
          this.routeEndPoint = endPoint;

          // 当起点和终点都有时开始规划路线
          this.showRoute = true;
        });
      });
    },

    // 从当前位置导航
    startNavigationFromCurrentLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          const point = new BMap.Point(
            position.coords.longitude,
            position.coords.latitude
          );
          this.routeStartPoint = point; // 设置起点为当前位置

          // 获取终点的经纬度
          const geocoder = new BMap.Geocoder();
          geocoder.getPoint(this.routeEnd, (endPoint) => {
            if (!endPoint) {
              this.$message.warning("终点地址无效");
              return;
            }
            this.routeEndPoint = endPoint;
            this.showRoute = true; // 显示路线
          });
        });
      }
    },

    // 定位当前位置
    locateCurrentPosition() {
      if (navigator.geolocation) {
        this.mapCenter = { lng: 114.27950005987421, lat: 30.774687706210035 };
        this.markerPosition = {
          lng: 114.27950005987421,
          lat: 30.774687706210035,
        };
      }
    },
  },
};
</script>

<style scoped>
.app-container {
  text-align: center;
  font-family: Arial, sans-serif;
}

.nav-bar {
  font-size: 18px;
}

.main-content {
  padding: 20px;
}

.input-card {
  margin-bottom: 20px;
  box-shadow: 0 4px 12px rgba(44, 110, 179, 0.15);
  border-radius: 10px;
  background-color: #fff;
}

.map {
  width: 100%;
  height: 500px;
  border-radius: 8px;
}

.input-section {
  padding: 20px;
}

.input-row {
  margin-bottom: 15px;
}

.styled-input {
  border-radius: 4px;
  border: 1px solid #2c6eb3;
}

.styled-input:hover {
  border-color: #409eff;
}

.styled-select {
  width: 100%;
}

.action-btn {
  background-color: #2c6eb3;
  border-color: #2c6eb3;
  color: white;
  border-radius: 4px;
  padding: 10px 15px;
  transition: all 0.3s;
}

.action-btn:hover {
  background-color: #1e4d8c;
  border-color: #1e4d8c;
}

.large-btn {
  width: 48%;
  margin: 0 1%;
  background-color: #2c6eb3;
  border-color: #2c6eb3;
  color: white;
  padding: 12px 20px;
  font-size: 16px;
  border-radius: 6px;
  transition: all 0.3s;
}

.large-btn:hover {
  background-color: #1e4d8c;
  border-color: #1e4d8c;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(0, 0, 0, 0.1);
}

.action-row {
  margin-top: 20px;
  text-align: center;
}

.el-input__inner {
  height: 40px;
  line-height: 40px;
}

.el-select__caret {
  color: #2c6eb3;
}
</style>