<template>
  <div id="register">
    <!-- 背景容器 -->
    <div class="background">
      <div class="sakura" v-for="n in 30" :key="n"></div>
    </div>
    <el-container class="register-container">
      <el-card class="register-card">
        <h2 class="register-title">🌸 注册 / 登録 🌸</h2>
        <el-form
          :model="registerUser"
          :rules="rules"
          ref="registerForm"
          class="register-form"
        >
          <!-- 用户名输入 -->
          <el-form-item prop="name">
            <el-input
              v-model="registerUser.name"
              placeholder="请输入用户名 / ユーザー名を入力してください"
              class="form-input"
            ></el-input>
          </el-form-item>
          <!-- 邮箱输入 (可选) -->
          <el-form-item prop="email">
            <el-input
              v-model="registerUser.email"
              placeholder="请输入邮箱 / メールアドレスを入力してください"
              class="form-input"
            ></el-input>
          </el-form-item>
          <!-- 密码输入 -->
          <el-form-item prop="password">
            <el-input
              type="password"
              v-model="registerUser.password2"
              placeholder="请输入密码 / パスワードを入力してください"
              class="form-input"
            ></el-input>
          </el-form-item>

          <!-- 确认密码输入 -->
          <el-form-item prop="password2">
            <el-input
              type="password"
              v-model="registerUser.password"
              placeholder="请再次输入密码 / パスワードを再度入力してください"
              class="form-input"
            ></el-input>
          </el-form-item>
          <el-form-item >
            <el-select v-model="registerUser.identity" placeholder="请选择身份">
              <el-option label="管理员" value="manager"></el-option>
              <el-option label="员工" value="employee"></el-option>
            </el-select>
          </el-form-item>
          <!-- 注册按钮 -->
          <el-form-item class="submit-wrapper">
            <el-button
              type="primary"
              @click="submitForm('registerForm')"
              class="submit-btn"
              >注册 / 登録</el-button
            >
          </el-form-item>

          <!-- 登录链接 -->
          <el-form-item class="login-link">
            <span>已有账号？</span>
            <router-link to="/login">登录 / ログイン</router-link>
          </el-form-item>
        </el-form>
      </el-card>
    </el-container>
  </div>
</template>
<script>
export default {
  name: "register",
  data() {
    var validatePass2 = (rule, value, callback) => {
      if (value !== this.registerUser.password) {
        callback(new Error("两次输入密码不一致!"));
      } else {
        callback();
      }
    };
    return {
      registerUser: {
        name: "",
        email: "",
        password: "",
        password2: "",
        identity: "",
      },
      rules: {
        name: [
          { required: true, message: "用户名不能为空", trigger: "change" },
          {
            min: 2,
            max: 30,
            message: "长度在 2 到 30 个字符",
            trigger: "blur",
          },
        ],
        email: [
          {
            type: "email",
            required: true,
            message: "邮箱格式不正确",
            trigger: "blur",
          },
        ],
        password: [
          { required: true, message: "密码不能为空", trigger: "blur" },
          {
            min: 6,
            max: 30,
            message: "长度在 6 到 30 个字符",
            trigger: "blur",
          },
        ],
        password2: [
          { required: true, message: "确认密码不能为空", trigger: "blur" },
          {
            min: 6,
            max: 30,
            message: "长度在 6 到 30 个字符",
            trigger: "blur",
          },
          { validator: validatePass2, trigger: "blur" },
        ],
      },
    };
  },
  methods: {
    submitForm(formName) {
      this.$refs[formName].validate((valid) => {
        if (valid) {
          this.$axios
            .post("/apis/users/register", this.registerUser)
            .then((res) => {
              // 注册成功
              this.$message({
                message: "注册成功！",
                type: "success",
              });
              this.$router.push("/login");
            });
        } else {
          console.log("error submit!!");
          return false;
        }
      });
    },
  },
};
</script>


<style scoped>
/* 背景动画容器 */
.background {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: #fce4ec;
  overflow: hidden;
  z-index: -1;
}

/* 樱花飘落动画 */
.sakura {
  position: absolute;
  width: 100%;
  height: 100%;
  background-image: url("@/assets/sakura.jpeg"); /* 使用高分辨率图片 */
  background-size: cover;
  background-position: center;
  image-rendering: crisp-edges;
  filter: brightness(1.1) contrast(1.1) saturate(1.2);
  opacity: 0.8;
  will-change: transform, opacity;
  animation: fall 10s linear infinite;
}

@keyframes fall {
  0% {
    transform: translateY(-100%) rotate(0deg);
  }
  100% {
    transform: translateY(100vh) rotate(360deg);
  }
}

/* 随机设置位置和动画延迟 */
.sakura:nth-child(odd) {
  left: calc(100% * var(--pos));
  animation-duration: calc(5s + var(--delay) * 3s);
}

.sakura:nth-child(even) {
  left: calc(100% * var(--pos));
  animation-duration: calc(6s + var(--delay) * 3s);
}

/* 注册容器 */
.register-container {
  height: 100vh;
  display: flex;
  justify-content: center;
  align-items: center;
}

/* 卡片样式 */
.register-card {
  width: 400px;
  padding: 20px;
  background-color: #fffaf0;
  border-radius: 12px;
  box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
}

/* 标题 */
.register-title {
  text-align: center;
  color: #d81b60;
  font-size: 24px;
  margin-bottom: 20px;
}

/* 输入框样式 */
.form-input {
  width: 100%;
}

/* 注册按钮 */
.submit-btn {
  background-color: #d81b60;
  color: white;
  width: 100%;
  padding: 12px;
  border-radius: 8px;
  font-size: 16px;
}

.submit-btn:hover {
  background-color: #ad1457;
}

/* 登录链接 */
.login-link {
  text-align: center;
  margin-top: 10px;
}

.login-link a {
  color: #d81b60;
}

.login-link a:hover {
  text-decoration: underline;
}
</style>