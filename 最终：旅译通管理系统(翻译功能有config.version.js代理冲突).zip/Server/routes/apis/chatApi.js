// 引入必要的模块
const express = require('express'); // Express 框架用于构建 Web 服务器
const axios = require('axios'); // Axios 用于发送 HTTP 请求
const cors = require('cors'); // CORS 处理跨域请求

// 创建一个 Express 路由对象
const router = express.Router();

// 定义 POST 路由 `/chat`，用于处理聊天请求
router.post('/chat', async (req, res) => {
    // 从请求体中获取 `model`（模型名称）、`messages`（对话信息）、`stream`（是否流式输出）
    const { model, messages, stream } = req.body;

    // 检查请求是否包含必要的字段
    if (!model || !messages) {
        return res.status(400).json({ error: '缺少必要字段: model 或 messages' });
    }

    try {
        // 发送日志，记录请求的模型和消息内容
        console.log(`请求 DeepSeek API，使用模型: ${model}，消息: ${JSON.stringify(messages)}...`);

        // 调用 DeepSeek API，向本地运行的 DeepSeek 服务发送聊天请求
        const response = await axios.post('http://localhost:11434/api/chat', {
            model,      // 指定使用的模型
            messages,   // 传递的对话内容
            stream,     // 是否启用流式响应
        });

        // 记录 DeepSeek 的响应日志
        console.log('DeepSeek API 响应成功。');

        // 将 DeepSeek API 的返回数据发送给前端
        res.json(response.data);
    } catch (error) {
        // 处理请求失败的情况
        console.error('调用 DeepSeek API 时发生错误:', error);

        // 如果 DeepSeek API 返回了错误响应
        if (error.response) {
            console.error('DeepSeek API 返回错误:', error.response.data);
            res.status(500).json({ error: error.response.data });
        } else {
            // 处理网络或其他错误
            console.error('网络错误:', error.message);
            res.status(500).json({ error: '无法连接到 DeepSeek 服务' });
        }
    }
});

// 导出路由模块，以便在其他文件中使用
module.exports = router;
