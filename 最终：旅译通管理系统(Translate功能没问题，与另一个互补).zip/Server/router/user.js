// 用户的路由模块

// 引入 Express 框架
const express = require('express');

// 创建一个路由对象，用于管理用户相关的路由
const router = express.Router();

// 引入 `express-joi` 中间件，用于验证表单数据
const expressjoi = require('@escook/express-joi');

// 引入用户数据验证规则
const { register } = require('../schema/user');

// 引入用户路由处理函数
const userHandler = require('../router_handler/user');

// 3. 在注册新用户的路由中，声明局部中间件，对请求携带的数据进行验证
// 3.1 如果数据验证通过，继续执行后续的路由处理函数
// 3.2 如果数据验证失败，终止请求，并抛出错误，进入全局错误处理中间件
router.post('/register', expressjoi(register), userHandler.resgister);

// 处理用户登录请求，使用相同的验证规则
router.post('/login', expressjoi(register), userHandler.login);

// 导出路由模块，以便在 `app.js` 或其他主文件中使用
module.exports = router;
