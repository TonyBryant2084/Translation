// 获取用户基本信息的模块

// 引入 Express 框架
const express = require('express');

// 创建路由对象
const router = express.Router();

// 导入数据验证中间件 `express-joi`，用于验证请求数据的合法性
const expressjoi = require('@escook/express-joi');

// 导入用户信息更新的验证规则对象
const { updateUserInfo } = require('../schema/userinfo'); // 更新用户基本信息
const { updatePwd } = require('../schema/user'); // 更新用户密码
const { updateAvatar } = require('../schema/user'); // 更新用户头像

// 导入用户信息相关的路由处理模块
const getUserInfo_handler = require('../router_handler/userinfo');

// 1. 获取用户基本信息的路由
//    通过 GET 请求获取当前用户的基本信息
router.get('/userinfo', getUserInfo_handler.getUserInfo);

// 2. 修改用户基本信息的路由
//    通过 POST 请求更新用户的基本信息，并使用 `express-joi` 进行数据验证
router.post('/userinfo', expressjoi(updateUserInfo), getUserInfo_handler.changeUserInfo);

// 3. 更新密码的路由
//    通过 POST 请求更新用户密码，确保数据格式符合 `updatePwd` 规则
router.post('/updatepwd', expressjoi(updatePwd), getUserInfo_handler.updatePassword);

// 4. 更新用户头像的路由
//    通过 POST 请求上传新的头像，并进行数据验证
router.post('/update/avatar', expressjoi(updateAvatar), getUserInfo_handler.updateAvatar);

// 5. 删除用户的路由
//    通过 POST 请求删除指定用户
router.post('/delete', getUserInfo_handler.deleteUser);

// 6. 获取所有用户信息的路由
//    通过 GET 请求展示所有用户信息
router.get('/show', getUserInfo_handler.showAllUser);

// 导出路由模块，以便在主文件（如 `app.js`）中使用
module.exports = router;
