// 导入数据库操作模块
const db = require('../db/index');

// 导入用于加密密码的 bcryptjs 包
const bcryptjs = require('bcryptjs');

// 导入用于生成和验证 JWT 令牌的 jsonwebtoken 包
const jwt = require('jsonwebtoken');

// 导入配置文件（包含 JWT 密钥和过期时间）
const config = require('../config');

// 注册用户的处理函数
function resgister(req, res) {
    // 获取客户端提交的用户信息
    const userinfo = req.body;

    // 校验用户名和密码是否为空
    if (!userinfo.username || !userinfo.password) {
        return res.cc('用户名或密码不合法');
    }

    // 定义 SQL 语句，查询用户名是否已被占用
    const sqlStr = 'SELECT * FROM ev_users WHERE username=?';
    db.query(sqlStr, userinfo.username, (err, result) => {
        if (err) {
            // 如果 SQL 语句执行失败，返回错误信息
            return res.cc(err);
        }

        if (result.length > 0) {
            // 如果查询结果不为空，说明用户名已被占用
            return res.cc('用户名重复，请更换用户名');
        }

        // 对用户的密码进行加密
        userinfo.password = bcryptjs.hashSync(userinfo.password, 10);
        console.log(userinfo);

        // 定义 SQL 语句，插入新用户
        const sqlin = 'INSERT INTO ev_users SET ?';
        db.query(sqlin, {
            username: userinfo.username,
            password: userinfo.password,
            email: userinfo.email
        }, (err, result) => {
            if (err) {
                // SQL 语句执行失败
                return res.cc('err');
            }

            if (result.affectedRows !== 1) {
                // 如果影响的行数不为 1，则说明注册失败
                return res.cc('注册用户失败，请稍后再试');
            }

            // 注册成功
            res.cc('注册成功！', 0);
        });
    });
}

// 用户登录的处理函数
function login(req, res) {
    // 获取客户端提交的用户信息
    const userinfo = req.body;

    // 定义 SQL 语句，查询用户名是否存在
    const sqlStr = 'SELECT * FROM ev_users WHERE username=?';
    db.query(sqlStr, userinfo.username, (err, result) => {
        if (err) {
            // 如果 SQL 语句执行失败，返回错误信息
            return res.cc(err);
        }

        if (result.length !== 1) {
            // 如果查询结果为空，说明用户名不存在
            return res.cc('用户名或密码错误!');
        }

        // 验证密码是否正确
        const comresult = bcryptjs.compareSync(userinfo.password, result[0].password);
        if (!comresult) {
            return res.cc('用户名或密码错误');
        }

        // 在服务器端生成 Token 字符串
        // 使用扩展运算符拷贝用户信息，并移除敏感信息（密码、用户头像）
        const user = { ...result[0], password: '', user_pic: '' };

        // 生成 Token，使用密钥和有效期
        const tokenStr = jwt.sign(user, config.jwtSecretkey, { expiresIn: config.expiresIn });

        // 返回 Token 及用户角色信息
        res.send({
            status: 0,
            msg: '登录成功',
            token: 'Bearer ' + tokenStr,
            role: result[0].role
        });
    });
}

// 导出注册和登录处理函数
module.exports = {
    resgister,
    login
};
