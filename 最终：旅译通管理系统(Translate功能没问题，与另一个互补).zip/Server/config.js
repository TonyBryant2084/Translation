//这是一个全局的配置文件
module.exports = {
    // 加密解密的token密钥
    jwtSecretkey: '^0^&&^_^||\/',
    expiresIn: '1h'
}