<template>
  <div class="hello">
    <!-- 显示传入的 msg 属性 -->
    <h1>{{ msg }}</h1>
    <p>
      如果你想了解如何配置/自定义这个项目的指南和示例，<br>
      请查看
      <a href="https://cli.vuejs.org" target="_blank" rel="noopener">vue-cli 文档</a>。
    </p>
    <h3>已安装的 CLI 插件</h3>
    <ul>
      <!-- 这里列出并链接到 Vue CLI 插件 -->
      <li><a href="https://github.com/vuejs/vue-cli/tree/dev/packages/%40vue/cli-plugin-babel" target="_blank" rel="noopener">babel</a></li>
      <li><a href="https://github.com/vuejs/vue-cli/tree/dev/packages/%40vue/cli-plugin-router" target="_blank" rel="noopener">router</a></li>
      <li><a href="https://github.com/vuejs/vue-cli/tree/dev/packages/%40vue/cli-plugin-eslint" target="_blank" rel="noopener">eslint</a></li>
    </ul>
    <h3>重要链接</h3>
    <ul>
      <!-- 这里列出并链接到 Vue 相关的官方资源 -->
      <li><a href="https://vuejs.org" target="_blank" rel="noopener">核心文档</a></li>
      <li><a href="https://forum.vuejs.org" target="_blank" rel="noopener">论坛</a></li>
      <li><a href="https://chat.vuejs.org" target="_blank" rel="noopener">社区聊天</a></li>
      <li><a href="https://twitter.com/vuejs" target="_blank" rel="noopener">Twitter</a></li>
      <li><a href="https://news.vuejs.org" target="_blank" rel="noopener">新闻</a></li>
    </ul>
    <h3>生态系统</h3>
    <ul>
      <!-- 这里列出并链接到 Vue 生态系统相关的工具和资源 -->
      <li><a href="https://router.vuejs.org" target="_blank" rel="noopener">vue-router</a></li>
      <li><a href="https://vuex.vuejs.org" target="_blank" rel="noopener">vuex</a></li>
      <li><a href="https://github.com/vuejs/vue-devtools#vue-devtools" target="_blank" rel="noopener">vue-devtools</a></li>
      <li><a href="https://vue-loader.vuejs.org" target="_blank" rel="noopener">vue-loader</a></li>
      <li><a href="https://github.com/vuejs/awesome-vue" target="_blank" rel="noopener">awesome-vue</a></li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'HelloWorld', // 定义组件的名称
  props: {
    msg: String // 接收一个名为 msg 的属性，类型为 String
  }
}
</script>

<!-- 使用 scoped 属性限制 CSS 只作用于当前组件 -->
<style scoped>
h3 {
  margin: 40px 0 0; /* 设置 h3 元素的上外边距 */
}
ul {
  list-style-type: none; /* 去掉无序列表的默认样式 */
  padding: 0; /* 去掉无序列表的内边距 */
}
li {
  display: inline-block; /* 将列表项显示为行内块元素 */
  margin: 0 10px; /* 设置列表项的左右外边距 */
}
a {
  color: #42b983; /* 设置链接的颜色 */
}
</style>
