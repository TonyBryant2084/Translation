import axios from 'axios';

// 允许跨域携带 Cookies
axios.defaults.withCredentials = true;

// 请求拦截器
axios.interceptors.request.use(
  config => {
    const token = localStorage.getItem('token'); // 从 localStorage 中获取 token
    if (token) {
      config.headers['Authorization'] = `${token}`; // 在请求头中携带 token
    }
    return config;
  },
  error => {
    return Promise.reject(error); // 请求错误时返回错误
  }
);

// 响应拦截器
axios.interceptors.response.use(
  response => response, // 请求成功时直接返回响应
  error => {
    if (error.response) {
      // 如果服务器返回了响应
      if (error.response.status === 401) {
        console.error('未授权，跳转到登录页面');
        window.location.href = '/login'; // token 失效，跳转到登录页面
      } else if (error.response.status === 403) {
        console.error('没有权限'); // 无权限访问
      } else {
        console.error('响应错误:', error.response.data); // 其他错误
      }
    } else if (error.request) {
      // 如果请求已发出但没有收到响应
      console.error('请求未收到响应:', error.request);
    } else {
      // 请求配置错误
      console.error('请求配置错误:', error.message);
    }
    return Promise.reject(error); // 返回错误
  }
);

export default axios; // 导出axios实例
