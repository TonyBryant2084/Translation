<template>
  <div id="app">
    <!-- 顶部导航栏 -->
    <el-menu
      :default-active="activeIndex"
      class="nav-bar"
      mode="horizontal"
      background-color="#2c6eb3"
      text-color="#fff"
      active-text-color="#ff8c1a"
    >
      <el-menu-item index="1">
        <span class="menu-item">
          <span class="cn-text">旅译通 / 旅译通</span>
        </span>
      </el-menu-item>
      <el-menu-item index="2">
        <span class="menu-item">
          <span class="cn-text"> 
            <router-link to="/" style="text-decoration: none">
            首页 / ホーム</router-link>
            </span>
        </span>
      </el-menu-item>
      <el-menu-item index="3">
        <span class="menu-item">
          <span class="cn-text">
            <router-link to="/recommend" style="text-decoration: none">推荐景点 / おすすめスポットです</router-link>
          </span>
        </span>
      </el-menu-item>
      <el-menu-item index="4">
        <span class="menu-item">
          <router-link to="/translate" style="text-decoration: none">
            翻译/翻訳
          </router-link>
        </span>
      </el-menu-item>
      <el-menu-item index="5">
        <span class="menu-item">
          <router-link to="/map" style="text-decoration: none">
            地图/地図
          </router-link>
        </span>
      </el-menu-item>
      <el-menu-item index="6">
        <span class="menu-item">
          <router-link to="/user" style="text-decoration: none">
            个人管理
          </router-link>
        </span>
      </el-menu-item>
    </el-menu>

    <div class="chat-container">
      <!-- 添加标题 -->
      <div class="chat-header">
        <span class="chat-title">旅小易</span>
      </div>

      <div class="messages" ref="messagesContainer">
        <div v-for="(message, index) in messages" :key="index" :class="['message', message.role]">
          <div class="message-content" v-html="formatMessageContent(message.content)"></div>
          <!-- 添加语音播放按钮 -->
          <button v-if="message.role === 'assistant'" class="speak-button" @click="speakMessage(message.content)">
            播放语音
          </button>
        </div>
      </div>

      <div class="input-container">
        <input v-model="userMessage" type="text" placeholder="请输入您的消息" @keyup.enter="sendMessage" />
        <button @click="sendMessage">发送</button>
      </div>
    </div>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      userMessage: '',
      messages: [],
      activeIndex: '3', // 默认选中推荐景点（index为3）
    };
  },
  methods: {
    async sendMessage() {
      if (this.userMessage.trim()) {
        // 显示用户的消息
        this.messages.push({ role: 'user', content: this.userMessage.trim() });

        // 清空输入框
        const userMessage = this.userMessage.trim();
        this.userMessage = '';

        // 滚动到底部
        this.$nextTick(() => {
          this.$refs.messagesContainer.scrollTop = this.$refs.messagesContainer.scrollHeight;
        });

        try {
          // 调用后端 API
          const response = await axios.post('http://localhost:80/chat', {
            model: 'deepseek-r1:1.5b',
            messages: [{ role: 'user', content: userMessage }], 
            stream: false,
          });

          // 显示 DeepSeek 的回复
          if (response.data && response.data.message) {
            const aiMessage = response.data.message.content.trim(); // 去掉前后空白
            this.messages.push({ role: 'assistant', content: '' });

            // 逐字显示 DeepSeek 回复的内容
            this.typeMessage(aiMessage);
          }
        } catch (error) {
          console.error('发生错误:', error);
          this.messages.push({ role: 'assistant', content: '发生错误，请稍后再试！' });
        }
      }
    },
    typeMessage(message) {
      let index = 0;
      const messageLength = message.length;
      const interval = setInterval(() => {
        // 逐字加载消息
        this.messages[this.messages.length - 1].content += message[index];
        index++;

        // 如果消息显示完毕，停止定时器
        if (index >= messageLength) {
          clearInterval(interval);
        }
      }, 25); // 50ms 每次添加一个字
    },
    // 格式化消息内容
    formatMessageContent(content) {
      // 移除 <think> 标签
      content = content.replace(/<think>.*?<\/think>/g, '');

      // 将 Markdown 格式转换为 HTML
      content = content
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>') // **加粗**
        .replace(/\*(.*?)\*/g, '<em>$1</em>') // *斜体*
        .replace(/^- (.*?)(\n|$)/gm, '<li>$1</li>') // - 列表项
        .replace(/(<li>.*<\/li>)/g, '<ul>$1</ul>') // 将列表项包裹在 <ul> 中
        .replace(/^### (.*?)(\n|$)/gm, '<h3>$1</h3>') // ### 标题
        .replace(/^## (.*?)(\n|$)/gm, '<h2>$1</h2>') // ## 标题
        .replace(/^# (.*?)(\n|$)/gm, '<h1>$1</h1>'); // # 标题

      // 去除多余的换行符和空格
      content = content.replace(/\n+/g, ' ').replace(/\s+/g, ' ').trim();

      return content;
    },
    // 播放消息语音
    speakMessage(message) {
      const speech = new SpeechSynthesisUtterance(message);
      speech.lang = 'zh-CN'; // 设置语言为中文
      speech.rate = 1; // 设置语速
      window.speechSynthesis.speak(speech);
    },
  },
};
</script>

<style scoped>
html,
body {
  margin: 0;
  padding: 0;
  height: 100%;
  width: 100%;
}

#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  padding: 0;
  margin: 0;
  height: 100vh;
  display: flex;
  flex-direction: column;
  background-image: url('@/assets/background.jpg');
  /* 背景图片 */
  background-size: cover;
  background-position: center;
  background-repeat: no-repeat;
}

.chat-container {
  width: 100%;
  max-width: 600px;
  height: 80vh;
  background-color: rgba(255, 255, 255, 0.8);
  /* 设置聊天框透明背景 */
  border-radius: 20px;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  margin-top: 80px;
  /* 留出顶部空间，避免与固定导航重叠 */

  /* 使用flexbox使聊天框居中 */
  position: absolute;
  top: 45%;
  left: 50%;
  transform: translate(-50%, -50%);
}

.chat-header {
  padding: 15px;
  background-color: rgba(255, 255, 255, 0.7);
  /* 设置标题背景色 */
  text-align: center;
  font-size: 24px;
  font-weight: bold;
  color: #333;
  border-top-left-radius: 20px;
  border-top-right-radius: 20px;
}

.chat-title {
  font-size: 24px;
  color: #007bff;
}

.messages {
  flex: 1;
  padding: 20px;
  overflow-y: auto;
  background-color: rgba(255, 255, 255, 0.1);
  /* 稍微透明，确保内容清晰 */
  border-bottom: 1px solid #eee;
}

.message {
  margin-bottom: 15px;
  display: flex;
}

.message.user {
  justify-content: flex-end;
}

.message.assistant {
  justify-content: flex-start;
}

.message-content {
  max-width: 70%;
  padding: 15px 20px;
  border-radius: 15px;
  position: relative;
  background: linear-gradient(135deg, #f1f7fb, #e3f2fd);
  color: #333;
  /* 文字颜色保持不透明 */
  word-wrap: break-word;
  white-space: pre-wrap;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
  font-size: 16px;
}

.message.user .message-content {
  background-color: #007bff;
  color: black;
  border-bottom-right-radius: 0;
  box-shadow: 0 4px 10px rgba(0, 123, 255, 0.3);
}

.message.assistant .message-content {
  background-color: #e1f7e0;
  color: #333;
  border-bottom-left-radius: 0;
}

.input-container {
  display: flex;
  padding: 10px;
  background-color: #ffffff;
  border-top: 1px solid #eee;
}

input {
  flex: 1;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 8px;
  margin-right: 10px;
  font-size: 14px;
  transition: border-color 0.3s ease;
}

input:focus {
  border-color: #007bff;
}

button {
  padding: 12px 20px;
  background-color: #007bff;
  color: white;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease, transform 0.3s ease;
}

button:hover {
  background-color: #0056b3;
  transform: translateY(-2px);
}

button:active {
  background-color: #003f7f;
  transform: translateY(0);
}

/* 语音播放按钮样式 */
.speak-button {
  margin-top: 10px;
  padding: 8px 15px;
  background-color: #4caf50;
  color: white;
  border: none;
  border-radius: 5px;
  cursor: pointer;
  font-size: 14px;
  transition: background-color 0.3s ease, transform 0.3s ease;
}

.speak-button:hover {
  background-color: #45a049;
  transform: translateY(-2px);
}

.speak-button:active {
  background-color: #3e8e41;
  transform: translateY(0);
}
</style>
