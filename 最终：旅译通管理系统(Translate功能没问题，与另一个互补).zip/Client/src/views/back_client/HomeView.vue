<template>
  <div class="dashboard-container">
    <el-container style="height: 100vh; border: 1px solid #eee">
      <!-- 头部 -->
      <el-header class="header" style="background-color: rgb(238, 241, 246)">
        <span style="font-size: 24px; font-weight: bold; color: #409eff"
          >旅译通后台管理系统</span
        >
      </el-header>

      <el-container>
        <!-- 侧边栏 -->
        <el-aside
          width="230px"
          style="border-right: 1px solid #eee; background-color: #fff"
        >
          <el-menu
            :default-openeds="['1']"
            class="el-menu-vertical-demo"
            background-color="#fff"
            text-color="#333"
            active-text-color="#409EFF"
          >
            <el-submenu index="1">
              <template slot="title">
                <i class="el-icon-s-tools"></i>
                <span>系统信息管理</span>
              </template>
              <el-menu-item-group>
                <el-menu-item index="1-1">
                  <router-link to="/bachome" class="menu-link">首页</router-link>
                </el-menu-item>
                <el-menu-item index="1-2">
                  <router-link to="/about" class="menu-link"
                    >信息管理</router-link
                  >
                </el-menu-item>
              </el-menu-item-group>
            </el-submenu>
          </el-menu>
        </el-aside>

        <!-- 主内容区 -->
        <el-main style="background-color: #f5f7fa; padding: 20px">
          <!-- 空内容区域 -->
          <el-empty
            image="https://img.520wangming.com/uploads/allimg/190529/3-1Z529115317.jpg"
            description="欢迎来到后台管理系统"
          >
            <!-- 退出登录按钮 -->
            <el-button type="primary" @click="onSubmit">退出登录</el-button>
          </el-empty>
        </el-main>
      </el-container>
    </el-container>
  </div>
</template>

<script>
// import axios from "axios";

export default {
  data() {
    return {
      tableData: [], // 存储表格数据
      formInline: {
        user: "",  // 用户名
        region: "",  // 地区
        address: "",  // 地址
        data: [],  // 数据
      },
    };
  },
  methods: {
    // 退出登录处理
    onSubmit() {
      localStorage.removeItem("token"); // 移除本地存储的token
      this.$router.push("/login"); // 跳转到登录页面
    },
  },
  mounted() {
    // 发送异步请求,获取请求数据
    // axios.get('/api/data').then(response => {
    //   this.tableData = response.data; // 更新表格数据
    // });
  },
};
</script>

<style scoped>
.dashboard-container {
  height: 100vh; /* 设置容器高度为100vh */
  display: flex;
  flex-direction: column; /* 纵向排列 */
}

.header {
  display: flex; /* 使用flex布局 */
  align-items: center; /* 垂直居中对齐 */
  justify-content: space-between; /* 两端对齐 */
  padding: 0 20px;
  box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1); /* 添加阴影效果 */
}

.menu-link {
  text-decoration: none; /* 去除链接下划线 */
  color: inherit; /* 继承颜色 */
}

.el-menu-vertical-demo {
  border-right: none; /* 去除右边框 */
}

.el-main {
  display: flex; /* 使用flex布局 */
  justify-content: center; /* 水平居中对齐 */
  align-items: center; /* 垂直居中对齐 */
}

.el-empty {
  text-align: center; /* 文本居中 */
}

.el-button {
  margin-top: 20px; /* 添加顶部间距 */
}

</style>
