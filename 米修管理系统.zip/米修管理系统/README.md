# Capital-management-system-with-authority

2022/07/25

基于vue2/Element-ui/node.js(express)/mongodb实现的资金管理系统

基于本视频 https://www.bilibili.com/video/BV1R341167Fw 练习

mongodb本地配置,可以按照 https://www.runoob.com/mongodb/mongodb-window-install.html 配置

感谢 @技术小余哥 https://space.bilibili.com/419040646 的项目视频,学到了很多ღ( ´･ᴗ･` )

觉得有帮助的话就点个小星星吧~

***
2022/07/27
更新了笔记(持续更新中)

2022/07/28
路由的写法已经旧了,之后再改

2022/12/30
修复了项目的错误,各类npm包已更新至当前日期的最新版本，并确保项目运行无误，笔记好久没更新了捏，有时间会更新后端的注释，前端vue2暂时不想看_(:з」∠)_，2018年的教程到现在也依旧有着生命力(oﾟvﾟ)b

2023/04/20
再次更新内部错误，能继续使用了。
离线版mongodb下载:https://www.mongodb.com/try/download/community

***
