const now_port = require("./server")

console.log(now_port);