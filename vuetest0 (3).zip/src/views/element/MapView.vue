<template>
  <div id="app">
    <!-- 外部容器，防止水平滚动 -->
    <el-container style="height: 80vh; display: flex; margin: 0; overflow-x: hidden;">
      <!-- 左侧导航栏 -->
      <el-aside width="200px" style="background-color: #f4f6f9; border-right: 1px solid #ddd; padding: 20px; box-shadow: 2px 0px 5px rgba(0,0,0,0.1);">
  <span style="font-size: 24px; font-weight: bold; display: block; text-align: center; color: #409EFF;">旅译通</span>
  <el-menu :default-openeds="['1', '3']" active-text-color="#409EFF" style="overflow: hidden;">
    <el-submenu index="1">
      <template #title>菜单/メニュー</template>
      <el-menu-item-group>
        <el-menu-item index="1-1">
          <router-link to="/translate" style="text-decoration: none;">翻译/翻訳</router-link>
        </el-menu-item>
        <el-menu-item index="1-2">
          <router-link to="/map" style="text-decoration: none;">地图/地図</router-link>
        </el-menu-item>
        <el-menu-item index="1-3">
          <router-link to="/user" style="text-decoration: none;">个人管理</router-link>
        </el-menu-item>
      </el-menu-item-group>
    </el-submenu>
  </el-menu>
</el-aside>

      <!-- 主内容区域 -->
      <el-container style="flex-grow: 1; display: flex; flex-direction: column; padding: 20px; overflow-x: hidden;">
        <el-header style="text-align: center; font-size: 20px; line-height: 40px; height: 40px; background-color: #409EFF; color: #fff; border-radius: 10px;">
          地图展示
        </el-header>

        <!-- 地图容器 -->
        <el-main style="flex-grow: 1; padding: 0; overflow-y: auto; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 10px;">
          <baidu-map class="map" :center="mapCenter" :zoom="zoom" ref="baiduMap" @ready="onMapLoaded">
            <bm-view class="map"></bm-view>
            <bm-navigation anchor="BMAP_ANCHOR_TOP_RIGHT"></bm-navigation>
            <bm-map-type :map-types="['BMAP_NORMAL_MAP', 'BMAP_HYBRID_MAP']" anchor="BMAP_ANCHOR_TOP_LEFT"></bm-map-type>
            <bm-marker :position="markerPosition" :dragging="true" @dragend="handleMarkerDragEnd"></bm-marker>
            <bm-driving
              v-if="showRoute && routeType === 'driving'"
              :start="routeStartPoint"
              :end="routeEndPoint"
              :auto-viewport="true"
              :policy="routePolicy"
              @searchcomplete="onRouteComplete"
            ></bm-driving>
            <bm-transit
              v-if="showRoute && routeType === 'transit'"
              :start="routeStartPoint"
              :end="routeEndPoint"
              :auto-viewport="true"
              @searchcomplete="onRouteComplete"
            ></bm-transit>
            <bm-walking
              v-if="showRoute && routeType === 'walking'"
              :start="routeStartPoint"
              :end="routeEndPoint"
              :auto-viewport="true"
              @searchcomplete="onRouteComplete"
            ></bm-walking>
          </baidu-map>
        </el-main>
      </el-container>
    </el-container>

    <!-- 输入框区域 -->
    <div style="padding: 10px 20px; width: 100%; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box; position: fixed; bottom: 80px; z-index: 1000;">
      <div style="display: flex; align-items: center; margin-bottom: 10px; width: 100%; box-sizing: border-box;">
        <el-input
          v-model="searchQuery"
          placeholder="请输入地点名称"
          style="flex-grow: 1; margin-right: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);"
        ></el-input>
        <el-button 
          type="primary" 
          style="font-size: 16px; padding: 10px;" 
          @click="searchLocation">
          搜索
        </el-button>
      </div>

      <div style="display: flex; align-items: center; width: 100%; box-sizing: border-box;">
        <el-input
          v-model="routeStart"
          placeholder="请输入起点"
          style="flex-grow: 1; margin-right: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);"
        ></el-input>
        <el-input
          v-model="routeEnd"
          placeholder="请输入终点"
          style="flex-grow: 1; margin-right: 10px; font-size: 16px; border-radius: 6px; box-shadow: 0px 2px 5px rgba(0,0,0,0.1);"
        ></el-input>
        <el-button 
          type="primary" 
          style="font-size: 16px; padding: 10px;" 
          @click="planRoute">
          规划路线
        </el-button>
      </div>
    </div>

    <!-- 底部按钮区域 -->
    <div style="position: fixed; bottom: 20px; left: 0; right: 0; padding: 20px; background-color: #fff; box-shadow: 0px -2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box;">
      <div style="display: flex; gap: 10px; width: 100%; box-sizing: border-box;">
        <el-radio-group v-model="routeType" style="flex-grow: 1;">
          <el-radio-button label="driving">自驾</el-radio-button>
          <el-radio-button label="transit">公交地铁</el-radio-button>
          <el-radio-button label="walking">步行</el-radio-button>
        </el-radio-group>

        <el-button 
          type="primary" 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="startNavigationFromCurrentLocation">
          从当前位置导航
        </el-button>

        <el-button 
          type="primary" 
          style="flex-grow: 1; font-size: 16px; padding: 10px;" 
          @click="locateCurrentPosition">
          定位到当前位置
        </el-button>
      </div>
    </div>

    <!-- 导航路线信息 -->
    <div v-if="routeInfo" style="position: fixed; top: 320px; right: 20px; padding: 20px; background-color: #fff; box-shadow: 0px 2px 5px rgba(0,0,0,0.1); border-radius: 8px; box-sizing: border-box; z-index: 1000;">
      <h3 style="margin-bottom: 10px;">导航路线信息</h3>
      <div v-if="routeType === 'driving'">
        <p><strong>时间:</strong> {{ routeInfo.time }}</p>
        <p><strong>路程:</strong> {{ routeInfo.distance }}</p>
      </div>
      <div v-if="routeType === 'transit'">
        <p><strong>时间:</strong> {{ routeInfo.time }}</p>
        <p><strong>路程:</strong> {{ routeInfo.distance }}</p>
        
        <ul>
          <li v-for="(step, index) in routeInfo.steps" :key="index">
            {{ step.description }}
            <span v-if="step.lines && step.lines.length">（{{ step.lines.join(' → ') }}）</span>
          </li>
        </ul>
      </div>
      <div v-if="routeType === 'walking'">
        <p><strong>时间:</strong> {{ routeInfo.time }}</p>
        <p><strong>路程:</strong> {{ routeInfo.distance }}</p>
      </div>
    </div>

    <!-- POI 详情弹窗 -->
    <!-- <el-dialog
      :visible.sync="showPOIDialog"
      :title="selectedPOI?.name"
      width="30%"
    >
      <div v-if="selectedPOI">
        <p><strong>简介：</strong>{{ selectedPOI.description }}</p>
      </div>
    </el-dialog> -->
  </div>
</template>

<script>
/* global BMap */
export default {
  name: 'MapView',
  data() {
    return {
      mapCenter: { lng: 114.305, lat: 30.592 }, // 默认地图中心点为武汉
      zoom: 15, // 缩放级别
      markerPosition: { lng: 114.305, lat: 30.592 }, // 标记点位置
      searchQuery: '', // 搜索框内容
      routeStart: '', // 路线起点（地址字符串）
      routeEnd: '', // 路线终点（地址字符串）
      routeStartPoint: null, // 路线起点（经纬度）
      routeEndPoint: null, // 路线终点（经纬度）
      showRoute: false, // 是否显示路线
      routeType: 'driving', // 导航模式（driving: 自驾, transit: 公交地铁, walking: 步行）
      routePolicy: 'BMAP_DRIVING_POLICY_LEAST_TIME', // 自驾路线规划策略
      mapLoaded: false, // 地图加载状态
      watchPositionId: null, // 实时位置监听的 ID
      routeInfo: null, // 导航路线信息
      showPOIDialog: false, // 是否显示 POI 详情弹窗
      selectedPOI: null, // 当前选中的 POI
    };
  },
  mounted() {
    // 确保百度地图 API 已加载
    if (window.BMap) {
      this.onMapLoaded();
    } else {
      // 如果百度地图 API 未加载完成，等待一段时间后重试
      const checkBaiduMap = setInterval(() => {
        if (window.BMap) {
          clearInterval(checkBaiduMap);
          this.onMapLoaded();
        }
      }, 100);
    }
  },
  methods: {
    // 地图加载完成事件
    onMapLoaded() {
      this.mapLoaded = true;
      console.log("地图加载完毕，可以搜索");

      // 添加 POI 点击事件监听
      const mapInstance = this.$refs.baiduMap.map;
      mapInstance.addEventListener('click', this.handleMapClick);
    },

    // 处理地图点击事件
    handleMapClick(e) {
  const mapInstance = this.$refs.baiduMap.map;
  const point = e.point;

  console.log('地图点击事件触发，点击位置:', point);

  // 确保 mapInstance 存在
  if (!mapInstance) {
    console.error('百度地图实例未初始化');
    return;
  }

  // 初始化 POI 搜索
  const localSearch = new BMap.LocalSearch(mapInstance, {
    renderOptions: { map: mapInstance },
    pageCapacity: 5, // 限制返回的 POI 数量
    enableAutoViewport: true, // 自动调整视角
    onSearchComplete: (results) => {
      console.log('搜索完成，搜索结果:', results);

      if (results && typeof results.getCurrentNumPois === 'function' && results.getCurrentNumPois() > 0) {
        const poi = results.getPoi(0);
        if (poi) {
          this.selectedPOI = {
            name: poi.title,
            address: poi.address || '暂无地址信息',
            point: poi.point
          };
          this.showPOIDialog = true;
          console.log('找到 POI:', this.selectedPOI);
        } else {
          console.warn('未找到有效 POI 数据');
        }
      } else {
        console.warn('未找到相关 POI');
      }
    },
    onSearchError: (error) => {
      console.error('搜索失败:', error);
    }
  });

  // 搜索点击位置附近的 POI
  console.log('开始搜索 POI');
  localSearch.searchNearby('景点', point, 100000); // 附近 500m 搜索“景点”
},

    // 搜索地点
    searchLocation() {
      const mapInstance = this.$refs.baiduMap.map;
      const geocoder = new BMap.Geocoder();

      geocoder.getPoint(this.searchQuery, (point) => {
        if (point) {
          mapInstance.centerAndZoom(point, this.zoom);
        } else {
          this.$message.warning('未找到相关地点');
        }
      });
    },

    // 规划路线
    planRoute() {
      //const mapInstance = this.$refs.baiduMap.map;
      const geocoder = new BMap.Geocoder();
      
      // 先获取起点和终点的经纬度
      geocoder.getPoint(this.routeStart, (point) => {
        if (point) {
          this.routeStartPoint = point;
        } else {
          this.$message.warning('起点地址无效');
        }
      });

      geocoder.getPoint(this.routeEnd, (point) => {
        if (point) {
          this.routeEndPoint = point;
        } else {
          this.$message.warning('终点地址无效');
        }
      });
      
      // 当起点和终点都有时开始规划路线
      if (this.routeStartPoint && this.routeEndPoint) {
        this.showRoute = true;
      }
    },

    // 从当前位置导航
    startNavigationFromCurrentLocation() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          const point = new BMap.Point(position.coords.longitude, position.coords.latitude);
          this.routeStartPoint = point;
          this.routeEndPoint = this.markerPosition;
          this.showRoute = true;
        });
      }
    },

    // 定位当前位置
    locateCurrentPosition() {
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition((position) => {
          const point = new BMap.Point(position.coords.longitude, position.coords.latitude);
          this.mapCenter = point;
          this.markerPosition = point;
          this.zoom = 16;
        });
      }
    }
  }
};
</script>

<style scoped>
.map {
  width: 100%;
  height: 100%;
  border-radius: 8px;
}
</style>