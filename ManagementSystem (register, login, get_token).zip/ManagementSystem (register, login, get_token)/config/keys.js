module.exports = {
    mongoURI: "mongodb+srv://tester:TonyBryant20040710@user-db.7q2mq.mongodb.net/?retryWrites=true&w=majority&appName=User-db",
    secretOrKey: "secret"

}